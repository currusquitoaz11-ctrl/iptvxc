
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import sys
import os
import urllib.request
import urllib.parse
import json
import re
import datetime
import time
import socket
import threading

# ==================== VARIABLES BÁSICAS ====================
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')

HOME = xbmcvfs.translatePath('special://home/')
ADDONDATA = os.path.join(HOME, 'userdata', 'addon_data', ADDON_ID)

if not os.path.exists(ADDONDATA):
    try:
        os.makedirs(ADDONDATA)
    except:
        pass

icon = os.path.join(ADDON_PATH, 'icon.png')
fanart = os.path.join(ADDON_PATH, 'fanart.jpg')

# Archivos de datos
FAVORITOS_FILE = os.path.join(ADDONDATA, 'favoritos.json')
HISTORIAL_FILE = os.path.join(ADDONDATA, 'historial.json')

# Cache para géneros
GENEROS_CACHE = None
SERIES_GENEROS_CACHE = None

# Variable global para el reproductor con grabación
_reproductor_actual = None

# ==================== FUNCIONES MULTI-SERVIDOR ====================
def get_server_urls():
    """Devuelve una lista con las tres URLs configuradas"""
    return [
        get_setting('server_url_1'),
        get_setting('server_url_2'),
        get_setting('server_url_3')
    ]

def set_server_url(index, url):
    """Guarda la URL en el servidor indicado (1,2,3)"""
    set_setting(f'server_url_{index}', url)

def get_active_server():
    """Devuelve el índice del servidor activo (1,2,3) según la configuración"""
    try:
        active = int(get_setting('active_server')) + 1
    except:
        active = 1
    if active < 1 or active > 3:
        active = 1
    return active

def activate_server(index):
    """Activa el servidor index (1,2,3): copia su URL a DNS y guarda active_server"""
    urls = get_server_urls()
    if index < 1 or index > 3:
        xbmc.log(f'{ADDON_ID}: activate_server índice inválido {index}', xbmc.LOGERROR)
        return False
    url = urls[index-1]
    if not url:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: Servidor {index} no tiene URL configurada.\n\nEdítala primero en "Editar Servidor {index}".')
        return False
    # Asegurar que la URL tenga protocolo
    if not url.startswith('http://') and not url.startswith('https://'):
        url_corregida = 'http://' + url
        if xbmcgui.Dialog().yesno(ADDON_NAME, f'La URL no tiene protocolo:\n{url}\n\n¿Deseas añadir http:// automáticamente?', yeslabel='Sí', nolabel='No'):
            url = url_corregida
            set_server_url(index, url)
        else:
            return False
    # Guardar la nueva URL activa
    set_setting('DNS', url)
    set_setting('active_server', str(index-1))
    xbmc.log(f'{ADDON_ID}: Servidor {index} activado. DNS ahora = {url}', xbmc.LOGINFO)
    xbmcgui.Dialog().notification(ADDON_NAME, f'Servidor {index} activado:\n{url}', icon, 5000)
    
    # Refrescar la ventana actual para que se vea el cambio
    xbmc.executebuiltin('Container.Refresh')
    return True

# ==================== FUNCIÓN DE LIMPIEZA DE TEXTO ====================
def limpiar_texto(texto):
    if not texto:
        return ''
    texto = str(texto)
    decorativos = r'[⬇⬆⬅➡🔴🟢🔵🟡⬤⬜⬛▪▫◼◻◽◾▬▭▮▯▰▱◆◇◈♢♤♧♡♥♦♠♣☺☻☼♀♂♫☀☁☂☃☄★☆☇☈☉☊☋☌☍☎☏☐☑☒☓☚☛☜☝☞☟☠☡☢☣☤☥☦☧☨☩☪☫☬☭☮☯]'
    texto = re.sub(decorativos, ' ', texto)
    texto = re.sub(r'[█▓▒░⎸⎹▀▄▌▐]', ' ', texto)
    texto = re.sub(r'[⬇⬆⬅➡]{2,}', ' ', texto)
    texto = re.sub(r'[Xx]+[\s]*[⬇⬆⬅➡█▓▒░]+', ' ', texto)
    texto = re.sub(r'[⬇⬆⬅➡█▓▒░]+[\s]*[Xx]+', ' ', texto)
    texto = re.sub(r'[^\w\s\u00C0-\u017F\u0400-\u04FF\-\.\,\?\!\(\)\[\]\:\;]', ' ', texto)
    texto = re.sub(r'\s+', ' ', texto).strip()
    if not texto:
        texto = re.sub(r'[^a-zA-Z0-9\s\u00C0-\u017F\u00F1\u00D1]', ' ', texto)
        texto = re.sub(r'\s+', ' ', texto).strip()
    return texto if texto else "Sin título"

# ==================== FUNCIONES AUXILIARES ====================
def add_item(name, url, mode, iconimage=None, description='', canal='', clean=True):
    if iconimage is None:
        iconimage = icon
    if clean:
        nombre_limpio = limpiar_texto(name)
    else:
        nombre_limpio = name
    plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(str(url)) + "&mode=" + str(mode) + "&name=" + urllib.parse.quote_plus(str(nombre_limpio)) + "&iconimage=" + urllib.parse.quote_plus(str(iconimage)) + "&description=" + urllib.parse.quote_plus(str(description)) + "&canal=" + urllib.parse.quote_plus(str(canal))
    li = xbmcgui.ListItem(nombre_limpio)
    li.setArt({'icon': iconimage, 'thumb': iconimage})
    li.setProperty('fanart_image', fanart)
    if mode == 4:
        li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=(mode != 4))

def get_setting(key):
    return ADDON.getSetting(key) or ''

def set_setting(key, value):
    ADDON.setSetting(key, str(value))

def get_creds():
    return get_setting('DNS'), get_setting('Username'), get_setting('Password')

def verificar_datos():
    vod_json = os.path.join(ADDONDATA, 'vod_streams.json')
    if not os.path.exists(vod_json):
        xbmcgui.Dialog().ok(ADDON_NAME, 'Primero entra en Películas para descargar los datos necesarios.')
        return False
    return True

def keypopup(heading, default='', hidden=False):
    kb = xbmc.Keyboard(default, heading, True)
    kb.setHeading(heading)
    kb.setHiddenInput(hidden)
    kb.doModal()
    if kb.isConfirmed():
        return kb.getText()
    return None

def mensaje_construccion():
    xbmcgui.Dialog().ok(ADDON_NAME, 'En construcción\n\nEsta función estará disponible próximamente.')

# ==================== CONFIGURACIÓN INICIAL ====================
def configurar_credenciales():
    dns = keypopup('Ingresa el DNS del servidor\nEj: http://tudns.com:8080')
    if dns is None:
        return
    set_setting('DNS', dns)
    set_server_url(1, dns)
    set_setting('active_server', '0')
    
    user = keypopup('Ingresa el nombre de usuario')
    if user is None:
        return
    set_setting('Username', user)
    
    pw = keypopup('Ingresa la contraseña', hidden=True)
    if pw is None:
        return
    set_setting('Password', pw)
    
    xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración guardada')
    xbmc.executebuiltin('Container.Refresh')

# ==================== FAVORITOS ====================
def cargar_favoritos():
    try:
        if os.path.exists(FAVORITOS_FILE):
            with open(FAVORITOS_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return []

def guardar_favoritos(favs):
    try:
        if not os.path.exists(ADDONDATA):
            os.makedirs(ADDONDATA)
        with open(FAVORITOS_FILE, 'w', encoding='utf-8') as f:
            json.dump(favs, f, ensure_ascii=False, indent=2)
    except:
        pass

def agregar_favorito(url, name, mode, iconimage, description, canal=''):
    favs = cargar_favoritos()
    for f in favs:
        if f.get('url') == url:
            return False
    favs.append({
        'url': url,
        'name': name,
        'mode': mode,
        'iconimage': iconimage,
        'description': description,
        'canal': canal,
        'timestamp': time.time()
    })
    guardar_favoritos(favs)
    return True

def eliminar_favorito(url):
    favs = cargar_favoritos()
    favs = [f for f in favs if f.get('url') != url]
    guardar_favoritos(favs)

def es_favorito(url):
    favs = cargar_favoritos()
    return any(f.get('url') == url for f in favs)

def mostrar_favoritos():
    favs = cargar_favoritos()
    if not favs:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No hay favoritos aún')
        return
    for fav in favs:
        nombre_mostrar = fav['name'] # Ejem [ES - PELICULAS 2026]
        nombre_canal = fav['name'] 
        if fav.get('canal'):
            nombre_mostrar = f"{nombre_canal}"
        
        plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(fav['url']) + "&mode=" + str(fav['mode']) + "&name=" + urllib.parse.quote_plus(nombre_mostrar) + "&iconimage=" + urllib.parse.quote_plus(fav.get('iconimage', icon)) + "&description=" + urllib.parse.quote_plus(fav.get('description', '')) + "&canal=" + urllib.parse.quote_plus(fav.get('canal', ''))
        li = xbmcgui.ListItem(nombre_mostrar)
        li.setArt({'icon': fav.get('iconimage', icon), 'thumb': fav.get('iconimage', icon)})
        li.setProperty('fanart_image', fanart)
        if fav['mode'] == 4:
            li.setProperty("IsPlayable", "true")
        
        cm = []
        # Opción eliminar favorito (siempre)
        cm.append(('Eliminar de Favoritos', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(fav["url"])}&name={urllib.parse.quote_plus(fav["name"])})'))
        
        # ✅ AÑADIR OPCIÓN DESCARGAR PARA TODOS LOS FAVORITOS
        # (si la URL no es descargable, el modo 200 mostrará error)
        cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?mode=200&url={urllib.parse.quote_plus(fav["url"])}&name={urllib.parse.quote_plus(nombre_mostrar)}&iconimage={urllib.parse.quote_plus(fav.get("iconimage", icon))}&canal={urllib.parse.quote_plus(fav.get("canal", ""))})'))
        
        li.addContextMenuItems(cm)
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=(fav['mode'] != 4))
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# ==================== HISTORIAL ====================
def cargar_historial():
    try:
        if os.path.exists(HISTORIAL_FILE):
            with open(HISTORIAL_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except:
        pass
    return []

def guardar_historial(hist):
    try:
        if not os.path.exists(ADDONDATA):
            os.makedirs(ADDONDATA)
        with open(HISTORIAL_FILE, 'w', encoding='utf-8') as f:
            json.dump(hist, f, ensure_ascii=False, indent=2)
    except:
        pass

def agregar_historial(url, name, iconimage, canal=''):
    hist = cargar_historial()
    hist = [h for h in hist if h.get('url') != url]
    hist.insert(0, {
        'url': url,
        'name': name,
        'iconimage': iconimage,
        'canal': canal,
        'timestamp': time.time()
    })
    hist = hist[:50]
    guardar_historial(hist)

def mostrar_historial():
    hist = cargar_historial()
    if not hist:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No hay historial aún')
        return
    for item in hist:
        nombre_mostrar = item['name']
        if item.get('canal'):
            nombre_mostrar = f"[{item['canal']}] {item['name']}"
        
        plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(item['url']) + "&mode=4&name=" + urllib.parse.quote_plus(nombre_mostrar) + "&iconimage=" + urllib.parse.quote_plus(item.get('iconimage', icon)) + "&description=" + urllib.parse.quote_plus(item.get('description', '')) + "&canal=" + urllib.parse.quote_plus(item.get('canal', ''))
        li = xbmcgui.ListItem(nombre_mostrar)
        li.setArt({'icon': item.get('iconimage', icon), 'thumb': item.get('iconimage', icon)})
        li.setProperty('fanart_image', fanart)
        li.setProperty('IsPlayable', 'true')
        
        cm = []
        cm.append(('Eliminar del Historial', f'RunPlugin({sys.argv[0]}?mode=34&url={urllib.parse.quote_plus(item["url"])}&name={urllib.parse.quote_plus(item["name"])})'))
        li.addContextMenuItems(cm)
        
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def limpiar_historial():
    guardar_historial([])
    xbmcgui.Dialog().ok(ADDON_NAME, 'Historial limpiado')

def eliminar_historial_item(url):
    hist = cargar_historial()
    hist = [h for h in hist if h.get('url') != url]
    guardar_historial(hist)

# ==================== REPRODUCCIÓN CON GRABACIÓN ====================

class RecordingPlayer(xbmc.Player):
    """Reproductor personalizado que permite grabar durante la reproducción"""
    
    def __init__(self):
        super().__init__()
        self.grabando = False
        self.archivo_grabacion = None
        self.response = None
        self.hilo_grabacion = None
        self.url_actual = ""
        self.nombre_actual = ""
        self.icon_actual = ""
        self.canal_actual = ""
        self.progress_dialog = None
        self.total_descargado = 0
        self.inicio_grabacion = 0
        self.duracion_maxima = 0
        
    def onPlayBackStarted(self):
        xbmc.log(f'IPTVXC: Reproducción iniciada', xbmc.LOGINFO)
        xbmcgui.Dialog().notification(ADDON_NAME, 'Presiona C y selecciona "Grabar" para guardar', icon, 5000)
        
    def onPlayBackStopped(self):
        xbmc.log(f'IPTVXC: Reproducción detenida', xbmc.LOGINFO)
        self.detener_grabacion()
        
    def onPlayBackEnded(self):
        xbmc.log(f'IPTVXC: Reproducción finalizada', xbmc.LOGINFO)
        self.detener_grabacion()
        
    def onPlayBackError(self):
        xbmc.log(f'IPTVXC: Error en reproducción', xbmc.LOGERROR)
        self.detener_grabacion()
        
    def iniciar_grabacion(self, url, nombre, iconimage, canal, duracion_maxima=0):
        if self.grabando:
            xbmcgui.Dialog().ok(ADDON_NAME, '⚠️ Ya hay una grabación en curso')
            return False
            
        try:
            download_path = xbmcgui.Dialog().browse(3, '📁 Selecciona carpeta para guardar la grabación', 'files')
            if not download_path:
                return False
            
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            nombre_limpio = re.sub(r'[<>:"/\\|?*]', '_', nombre)
            
            if canal:
                nombre_archivo = f"{canal} - {nombre_limpio} - {timestamp}.ts"
            else:
                nombre_archivo = f"{nombre_limpio} - {timestamp}.ts"
            
            self.archivo_grabacion = os.path.join(download_path, nombre_archivo)
            
            if os.path.exists(self.archivo_grabacion):
                if not xbmcgui.Dialog().yesno(ADDON_NAME, f'⚠️ El archivo ya existe:\n{nombre_archivo}\n\n¿Sobrescribir?'):
                    return False
            
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            req.add_header('Accept', '*/*')
            req.add_header('Connection', 'keep-alive')
            
            self.response = urllib.request.urlopen(req, timeout=30)
            self.url_actual = url
            self.nombre_actual = nombre
            self.icon_actual = iconimage
            self.canal_actual = canal
            self.grabando = True
            self.inicio_grabacion = time.time()
            self.duracion_maxima = duracion_maxima
            self.total_descargado = 0
            
            self.progress_dialog = xbmcgui.DialogProgress()
            self.progress_dialog.create(ADDON_NAME, f"GRABANDO: {nombre_limpio[:50]}")
            self.progress_dialog.update(0, "Iniciando grabación...")
            
            self.hilo_grabacion = threading.Thread(target=self._grabar_stream)
            self.hilo_grabacion.daemon = True
            self.hilo_grabacion.start()
            
            if duracion_maxima > 0:
                minutos = duracion_maxima // 60
                xbmcgui.Dialog().notification(ADDON_NAME, f'Grabando durante {minutos} minutos', icon, 3000)
            else:
                xbmcgui.Dialog().notification(ADDON_NAME, 'Grabando sin límite de tiempo', icon, 3000)
            
            return True
            
        except Exception as e:
            xbmc.log(f'IPTVXC: Error iniciando grabación: {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, f'Error al iniciar grabación:\n{str(e)[:100]}')
            return False
    
    def _grabar_stream(self):
        try:
            with open(self.archivo_grabacion, 'wb') as f:
                errores_consecutivos = 0
                ultima_actualizacion = 0
                
                while self.grabando and self.isPlaying():
                    try:
                        chunk = self.response.read(8192)
                        if not chunk:
                            break
                        
                        f.write(chunk)
                        self.total_descargado += len(chunk)
                        errores_consecutivos = 0
                        
                        ahora = time.time()
                        if ahora - ultima_actualizacion > 0.5:
                            ultima_actualizacion = ahora
                            mb = self.total_descargado // (1024 * 1024)
                            
                            if self.progress_dialog:
                                if self.duracion_maxima > 0:
                                    tiempo_restante = int(self.duracion_maxima - (ahora - self.inicio_grabacion))
                                    minutos_rest = tiempo_restante // 60
                                    seg_rest = tiempo_restante % 60
                                    self.progress_dialog.update(0, f"Grabado: {mb} MB\nRestante: {minutos_rest}m {seg_rest}s\nPresiona Cancelar para detener")
                                else:
                                    self.progress_dialog.update(0, f"Grabado: {mb} MB\nPresiona Cancelar para detener")
                        
                        if self.duracion_maxima > 0 and (time.time() - self.inicio_grabacion) > self.duracion_maxima:
                            break
                            
                        if self.progress_dialog and self.progress_dialog.iscanceled():
                           if xbmcgui.Dialog().yesno(ADDON_NAME, '¿Detener grabación?', '¿Conservar lo grabado hasta ahora?', yeslabel='Conservar', nolabel='Eliminar'):
                              self.conservar_parcial = True
                        break
                            
                    except Exception as e:
                        errores_consecutivos += 1
                        if errores_consecutivos >= 5:
                            break
                        xbmc.sleep(1000)
                        
        except Exception as e:
            xbmc.log(f'IPTVXC: Error en hilo de grabación: {e}', xbmc.LOGERROR)
        finally:
            self._finalizar_grabacion()
    
def _finalizar_grabacion(self):
    conservar = getattr(self, 'conservar_parcial', False)
    self.grabando = False
    
    if self.progress_dialog:
        self.progress_dialog.close()
        self.progress_dialog = None
        
    if self.response:
        try:
            self.response.close()
        except:
            pass
        self.response = None
    
    if self.archivo_grabacion and os.path.exists(self.archivo_grabacion):
        tamaño = os.path.getsize(self.archivo_grabacion)
        if tamaño > 10240 or conservar:
            mb = tamaño // (1024 * 1024)
            if conservar:
                xbmcgui.Dialog().notification(ADDON_NAME, f'Grabación parcial guardada: {mb} MB', icon, 5000)
            else:
                xbmcgui.Dialog().notification(ADDON_NAME, f'Grabación completada: {mb} MB', icon, 5000)
        else:
            os.remove(self.archivo_grabacion)
            if not conservar:
                xbmcgui.Dialog().ok(ADDON_NAME, '❌ Grabación fallida: archivo demasiado pequeño')
    else:
        if self.progress_dialog:
            xbmcgui.Dialog().ok(ADDON_NAME, '❌ Grabación cancelada')
    
    def detener_grabacion(self):
        if self.grabando:
            self.grabando = False
            xbmcgui.Dialog().notification(ADDON_NAME, '⏹️ Deteniendo grabación...', icon, 2000)


def play_video(url, name, iconimage, canal=''):
    global _reproductor_actual
    try:
        xbmc.log(f'IPTVXC: Reproduciendo: {url}', xbmc.LOGINFO)
        agregar_historial(url, name, iconimage, canal)
        
        li = xbmcgui.ListItem(limpiar_texto(name))
        li.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage})
        li.setPath(url)
        li.setProperty('IsPlayable', 'true')
        li.setProperty('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        li.setProperty('Accept', '*/*')
        li.setProperty('Connection', 'keep-alive')
        li.setProperty('cache', 'true')
        li.setProperty('cache-mem-buffers', '31457280')
        li.setProperty('cache-size', '30M')
        li.setProperty('readbuffer', 'true')
        li.setProperty('readbuffer-size', '30M')
        li.setProperty('conn-timeout', '30')
        
        if '.m3u8' in url or '/live/' in url:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        _reproductor_actual = RecordingPlayer()
        
        cm = []
        cm.append(('Grabar este contenido', f'RunPlugin({sys.argv[0]}?mode=210&url={urllib.parse.quote_plus(url)}&name={urllib.parse.quote_plus(name)}&iconimage={urllib.parse.quote_plus(iconimage)}&canal={urllib.parse.quote_plus(canal)})'))
        li.addContextMenuItems(cm)
        
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        
    except Exception as e:
        xbmc.log(f'IPTVXC: Error en play_video: {e}', xbmc.LOGERROR)
        opciones = ['Reintentar', 'Cancelar']
        if xbmcgui.Dialog().select('Error de reproducción', opciones) == 0:
            play_video(url, name, iconimage, canal)


# ==================== MENÚ PRINCIPAL ====================
def main_menu():
    # Mostrar servidor activo como primer elemento
    dns_activo = get_setting('DNS')
    active_idx = get_active_server()
    if dns_activo:
        servidor_mostrar = dns_activo.replace('http://', '').replace('https://', '')
        if len(servidor_mostrar) > 50:
            servidor_mostrar = servidor_mostrar[:47] + '...'
        texto_servidor = f"Servidor activo: {servidor_mostrar} (Servidor {active_idx})"
    else:
        texto_servidor = "Servidor no configurado"
    add_item(texto_servidor, 'server_settings', 99, icon, clean=False)
    
    add_item('Favoritos', 'favoritos', 30, icon)
    add_item('Historial', 'historial', 31, icon)
    add_item('Información de la Cuenta', 'account_info', 6, icon)
    add_item('TV en Vivo', 'live', 1, icon)
    add_item('Películas', 'movies', 3, icon)
    add_item('Series', 'series', 18, icon)
    add_item('Guía TV', 'tv_guide', 7, icon)
    add_item('Buscador', 'buscador', 5, icon)
    add_item('Configuración', 'config_menu', 8, icon)
    add_item('Generar M3U', 'm3u_menu', 100, icon)
    add_item('Extras', 'extras', 16, icon)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# ==================== CONFIGURACIÓN ====================
def config_menu():
    meta = get_setting('meta') == 'true'
    hidexxx = get_setting('hidexxx') == 'true'
    unblock = get_setting('dns_unblock') == 'true'
    gen_m3u = get_setting('generate_m3u') == 'true'

    meta_str = '[B][COLOR lime]ON[/COLOR][/B]' if meta else '[B][COLOR red]OFF[/COLOR][/B]'
    xxx_str = '[B][COLOR lime]ON[/COLOR][/B]' if hidexxx else '[B][COLOR red]OFF[/COLOR][/B]'
    unblock_str = '[B][COLOR lime]ON[/COLOR][/B]' if unblock else '[B][COLOR red]OFF[/COLOR][/B]'
    gen_str = '[B][COLOR lime]ON[/COLOR][/B]' if gen_m3u else '[B][COLOR red]OFF[/COLOR][/B]'

    add_item('Ajustes Servidor', 'server_settings', 99, icon, clean=False)
    add_item('Editar ajustes avanzados', 'ADS', 10, icon, clean=False)
    add_item(f'Desbloquear DNS: {unblock_str}', 'DNS_UNBLOCK', 10, icon, clean=False)
    add_item(f'META: {meta_str}', 'META', 10, icon, clean=False)
    add_item(f'Ocultar contenido Adultos: {xxx_str}', 'XXX', 10, icon, clean=False)
    add_item('Borrar claves y password', 'LO', 10, icon, clean=False)
    add_item(f'Generar listas M3U: {gen_str}', 'GENM3U', 10, icon, clean=False)
    add_item('Ejecutar prueba de velocidad', 'speedtest', 98, icon, clean=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def server_settings():
    """Diálogo para gestionar múltiples servidores con índices fijos"""
    try:
        dns_actual = get_setting('DNS')
        user = get_setting('Username')
        password = get_setting('Password')
        urls = get_server_urls()
        active_idx = get_active_server()
        
        # Construir la lista de opciones
        opciones = []
        opciones.append(f'DNS activo: {dns_actual if dns_actual else "NO CONFIGURADO"}')
        opciones.append('==== SERVIDORES ======')
        for i in range(3):
            estado = "ACTIVO" if (i+1) == active_idx else "○"
            url_mostrar = urls[i] if urls[i] else "[VACÍO]"
            opciones.append(f'{estado} Servidor {i+1}: {url_mostrar}')
        opciones.append('===== ACCIONES =====')
        opciones.append('Editar Servidor 1')
        opciones.append('Editar Servidor 2')
        opciones.append('Editar Servidor 3')
        opciones.append('Activar Servidor 1')
        opciones.append('Activar Servidor 2')
        opciones.append('Activar Servidor 3')
        opciones.append('= = = CREDENCIALES = = =')
        opciones.append('Editar Usuario')
        opciones.append('Editar Contraseña')
        opciones.append('Borrar todos los datos')
        opciones.append('Volver')
        
        seleccion = xbmcgui.Dialog().select('Ajustes de Servidores IPTV', opciones)
        if seleccion < 0:
            return
        
        # Log para depurar
        xbmc.log(f'{ADDON_ID}: server_settings selección = {seleccion} -> "{opciones[seleccion]}"', xbmc.LOGINFO)
        
        # Índices según orden de inserción:
        # 0: información DNS
        # 1: separador servidores
        # 2: info Servidor 1
        # 3: info Servidor 2
        # 4: info Servidor 3
        # 5: separador acciones
        # 6: Editar Servidor 1
        # 7: Editar Servidor 2
        # 8: Editar Servidor 3
        # 9: Activar Servidor 1
        # 10: Activar Servidor 2
        # 11: Activar Servidor 3
        # 12: separador credenciales
        # 13: Editar Usuario
        # 14: Editar Contraseña
        # 15: Borrar todos los datos
        # 16: Volver
        
        if seleccion == 6:   # Editar Servidor 1
            nuevo = keypopup('URL del Servidor 1\nEj: http://tuservidor.com:8080', urls[0])
            if nuevo is not None:
                set_server_url(1, nuevo)
                if active_idx == 1:
                    set_setting('DNS', nuevo)
                    xbmcgui.Dialog().notification(ADDON_NAME, 'Servidor activo actualizado', icon, 2000)
        elif seleccion == 7: # Editar Servidor 2
            nuevo = keypopup('URL del Servidor 2', urls[1])
            if nuevo is not None:
                set_server_url(2, nuevo)
                if active_idx == 2:
                    set_setting('DNS', nuevo)
        elif seleccion == 8: # Editar Servidor 3
            nuevo = keypopup('URL del Servidor 3', urls[2])
            if nuevo is not None:
                set_server_url(3, nuevo)
                if active_idx == 3:
                    set_setting('DNS', nuevo)
        elif seleccion == 9: # Activar Servidor 1
            activate_server(1)
        elif seleccion == 10: # Activar Servidor 2
            activate_server(2)
        elif seleccion == 11: # Activar Servidor 3
            activate_server(3)
        elif seleccion == 13: # Editar Usuario
            nuevo = keypopup('Ingresa el nombre de usuario', user)
            if nuevo is not None:
                set_setting('Username', nuevo)
        elif seleccion == 14: # Editar Contraseña
            nuevo = keypopup('Ingresa la contraseña', password, hidden=True)
            if nuevo is not None:
                set_setting('Password', nuevo)
        elif seleccion == 15: # Borrar todos los datos
            if xbmcgui.Dialog().yesno(ADDON_NAME, '¿Borrar DNS, Usuario, Contraseña y todos los servidores?'):
                set_setting('DNS', '')
                set_setting('Username', '')
                set_setting('Password', '')
                for i in range(1,4):
                    set_server_url(i, '')
                set_setting('active_server', '0')
                xbmcgui.Dialog().ok(ADDON_NAME, 'Todos los datos han sido borrados.')
                xbmc.executebuiltin('Container.Refresh')
        elif seleccion == 16: # Volver
            pass
    except Exception as e:
        xbmc.log(f'{ADDON_ID}: ERROR en server_settings: {e}', xbmc.LOGERROR)
        import traceback
        xbmc.log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error interno: {str(e)[:100]}')

def get_advancedsettings_path():
    return os.path.join(HOME, 'userdata', 'advancedsettings.xml')

def crear_advancedsettings_auto():
    path = get_advancedsettings_path()
    try:
        mem_free = xbmc.getInfoLabel('System.Memory(free)')
        mem_mb = int(float(mem_free.split()[0])) if mem_free else 500
    except:
        mem_mb = 500
    buffer_mb = min(200, max(50, int(mem_mb * 0.2)))
    content = f'''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>{buffer_mb * 1024 * 1024}</memorysize>
        <readfactor>20</readfactor>
    </cache>
    <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>5</curllowspeedtime>
        <curlretries>3</curlretries>
        <disableipv6>true</disableipv6>
    </network>
</advancedsettings>'''
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

def crear_advancedsettings_firetv_stick():
    path = get_advancedsettings_path()
    content = '''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>78643200</memorysize>
        <readfactor>20</readfactor>
    </cache>
    <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>5</curllowspeedtime>
        <curlretries>3</curlretries>
        <disableipv6>true</disableipv6>
    </network>
</advancedsettings>'''
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

def crear_advancedsettings_firetv():
    path = get_advancedsettings_path()
    content = '''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>157286400</memorysize>
        <readfactor>20</readfactor>
    </cache>
    <network>
        <curlclienttimeout>10</curlclienttimeout>
        <curllowspeedtime>5</curllowspeedtime>
        <curlretries>3</curlretries>
        <disableipv6>true</disableipv6>
    </network>
</advancedsettings>'''
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

def crear_advancedsettings_lessthan():
    path = get_advancedsettings_path()
    content = '''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>52428800</memorysize>
        <readfactor>15</readfactor>
    </cache>
    <network>
        <curlclienttimeout>8</curlclienttimeout>
        <curllowspeedtime>3</curllowspeedtime>
        <curlretries>2</curlretries>
        <disableipv6>true</disableipv6>
    </network>
</advancedsettings>'''
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

def crear_advancedsettings_morethan():
    path = get_advancedsettings_path()
    content = '''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>209715200</memorysize>
        <readfactor>25</readfactor>
    </cache>
    <network>
        <curlclienttimeout>15</curlclienttimeout>
        <curllowspeedtime>8</curllowspeedtime>
        <curlretries>4</curlretries>
        <disableipv6>true</disableipv6>
    </network>
</advancedsettings>'''
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

def crear_advancedsettings_shield():
    path = get_advancedsettings_path()
    content = '''<advancedsettings>
    <cache>
        <buffermode>1</buffermode>
        <memorysize>314572800</memorysize>
        <readfactor>30</readfactor>
    </cache>
    <network>
        <curlclienttimeout>20</curlclienttimeout>
        <curllowspeedtime>10</curllowspeedtime>
        <curlretries>5</curlretries>
        <disableipv6>true</disableipv6>
    </network>
</advancedsettings>'''
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)

def eliminar_advancedsettings():
    path = get_advancedsettings_path()
    if os.path.exists(path):
        try:
            os.remove(path)
        except:
            pass

def advanced_settings_menu():
    opciones = [
        'Abrir AutoConfig (Recomendado)',
        'Habilitar AS para Fire TV Stick (1GB)',
        'Habilitar AS para Fire TV (2GB)',
        'Habilitar AS para 1GB RAM o menos',
        'Habilitar AS para 2GB RAM o más',
        'Habilitar AS para Nvidia Shield',
        'Deshabilitar AS (Eliminar advancedsettings.xml)'
    ]
    seleccion = xbmcgui.Dialog().select('Editar Configuración Avanzada', opciones)
    if seleccion == 0:
        mostrar_autoconfig_dialog()
    elif seleccion == 1:
        crear_advancedsettings_firetv_stick()
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración para Fire TV Stick aplicada\nReinicia Kodi')
    elif seleccion == 2:
        crear_advancedsettings_firetv()
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración para Fire TV aplicada\nReinicia Kodi')
    elif seleccion == 3:
        crear_advancedsettings_lessthan()
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración para 1GB RAM aplicada\nReinicia Kodi')
    elif seleccion == 4:
        crear_advancedsettings_morethan()
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración para 2GB RAM aplicada\nReinicia Kodi')
    elif seleccion == 5:
        crear_advancedsettings_shield()
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración para Nvidia Shield aplicada\nReinicia Kodi')
    elif seleccion == 6:
        eliminar_advancedsettings()
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración avanzada eliminada\nReinicia Kodi')

def mostrar_autoconfig_dialog():
    try:
        mem_free = xbmc.getInfoLabel('System.Memory(free)')
        mem_mb = int(float(mem_free.split()[0])) if mem_free else 500
    except:
        mem_mb = 500
    buffer_recomendado = min(200, max(50, int(mem_mb * 0.2)))
    mensaje = f"Estas son las mejores configuraciones para tu dispositivo:\n\n"
    mensaje += f"Memoria libre detectada: {mem_mb} MB\n"
    mensaje += f"Buffer de caché recomendado: {buffer_recomendado} MB\n\n"
    mensaje += f"Configuración recomendada:\n"
    mensaje += f"- Buffer Mode: 1 (Buffer todas las fuentes)\n"
    mensaje += f"- Read Factor: 20\n"
    mensaje += f"- Curl Timeout: 10 segundos\n"
    mensaje += f"- IPv6: Deshabilitado\n\n"
    mensaje += f"¿Deseas aplicar esta configuración?"
    if xbmcgui.Dialog().yesno(ADDON_NAME, mensaje, yeslabel='¿Continuar?', nolabel='¿Salir?'):
        crear_advancedsettings_auto()
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configuración avanzada aplicada\nReinicia Kodi para que surta efecto')

def addonsettings(url, description):
    if url == "ADS":
        advanced_settings_menu()
    elif url == "DNS_UNBLOCK":
        estado = get_setting('dns_unblock') == 'true'
        if estado:
            set_setting('dns_unblock', 'false')
            xbmcgui.Dialog().notification(ADDON_NAME, 'Desbloqueo DNS: OFF', icon, 2000)
        else:
            set_setting('dns_unblock', 'true')
            xbmcgui.Dialog().notification(ADDON_NAME, 'Desbloqueo DNS: ON', icon, 2000)
        xbmc.sleep(500)
        xbmc.executebuiltin('Container.Refresh')
    elif url == "META":
        estado = get_setting('meta') == 'true'
        if estado:
            set_setting('meta', 'false')
            xbmcgui.Dialog().notification(ADDON_NAME, 'META: OFF', icon, 2000)
        else:
            set_setting('meta', 'true')
            xbmcgui.Dialog().notification(ADDON_NAME, 'META: ON', icon, 2000)
        xbmc.sleep(500)
        xbmc.executebuiltin('Container.Refresh')
    elif url == "XXX":
        estado = get_setting('hidexxx') == 'true'
        if estado:
            pas = keypopup('Ingresa la contraseña para adultos:', hidden=True)
            if pas == get_setting('xxx_pw'):
                set_setting('hidexxx', 'false')
                xbmcgui.Dialog().notification(ADDON_NAME, 'Contenido Adultos: OFF', icon, 2000)
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().ok(ADDON_NAME, 'Contraseña incorrecta')
        else:
            set_setting('hidexxx', 'true')
            xbmcgui.Dialog().notification(ADDON_NAME, 'Contenido Adultos: ON', icon, 2000)
            xbmc.sleep(500)
            xbmc.executebuiltin('Container.Refresh')
    elif url == "GENM3U":
        estado = get_setting('generate_m3u') == 'true'
        if estado:
            set_setting('generate_m3u', 'false')
            xbmcgui.Dialog().notification(ADDON_NAME, 'Generar M3U: OFF', icon, 2000)
        else:
            set_setting('generate_m3u', 'true')
            xbmcgui.Dialog().notification(ADDON_NAME, 'Generar M3U: ON', icon, 2000)
        xbmc.sleep(500)
        xbmc.executebuiltin('Container.Refresh')
    elif url == "LO":
        set_setting('DNS', '')
        set_setting('Username', '')
        set_setting('Password', '')
        xbmcgui.Dialog().ok(ADDON_NAME, 'Credenciales borradas')
        xbmc.executebuiltin('XBMC.ActivateWindow(Videos,addons://sources/video/)')
        xbmc.sleep(500)
        xbmc.executebuiltin('Container.Refresh')
    else:
        xbmc.executebuiltin(f'Addon.OpenSettings({ADDON_ID})')

# ==================== M3U ====================
def m3u_menu():
    add_item('TV', 'm3u_tv', 118, icon)
    add_item('PELÍCULAS', 'm3u_peliculas', 113, icon)
    add_item('SERIES', 'm3u_series', 114, icon)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def m3u_tv():
    add_item('BÁSICO - Todos los canales (sin metadatos)', 'm3u_tv_basico', 119, icon)
    add_item('COMPLETO - Por CANALES (con metadatos)', 'm3u_tv_completo', 120, icon)
    add_item('VER ARCHIVOS M3U', 'ver_archivos', 102, icon)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def m3u_peliculas():
    add_item('BÁSICO - Todos los canales (sin metadatos)', 'm3u_basico', 110, icon)
    add_item('COMPLETO - Por CANALES (con metadatos)', 'm3u_completo_canales', 111, icon)
    add_item('COMPLETO - Por GÉNEROS (con metadatos)', 'm3u_completo_generos', 112, icon)
    add_item('VER ARCHIVOS M3U', 'ver_archivos', 102, icon)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def m3u_series():
    add_item('BÁSICO - Todas las series (sin metadatos)', 'm3u_series_basico', 115, icon)
    add_item('COMPLETO - Por CANALES (con metadatos)', 'm3u_series_canales', 116, icon)
    add_item('COMPLETO - Por GÉNEROS (con metadatos)', 'm3u_series_generos', 117, icon)
    add_item('COMPLETO - Por CANALES (con temporadas)', 'm3u_series_canales_completo', 121, icon)
    add_item('VER ARCHIVOS M3U', 'ver_archivos', 102, icon)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# ==================== GENERAR M3U TV ====================
def generar_m3u_tv_basico():
    """Genera M3U básico de TV (sin metadatos)"""
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Generando lista básica de TV...")
    progress.update(0)

    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_streams"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=60)
        data = response.read().decode('utf-8')
        response.close()

        if not data:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudieron obtener canales')
            return

        canales = json.loads(data)
        total = len(canales)

        url_cats = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_categories"
        req2 = urllib.request.Request(url_cats)
        req2.add_header('User-Agent', 'Mozilla/5.0')
        response2 = urllib.request.urlopen(req2, timeout=15)
        data_cats = response2.read().decode('utf-8')
        response2.close()
        cat_id_to_name = {}
        if data_cats:
            for cat in json.loads(data_cats):
                cat_id_to_name[str(cat.get('category_id', ''))] = cat.get('category_name', 'TV')

        if not os.path.exists(ADDONDATA):
            os.makedirs(ADDONDATA)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        m3u_path = os.path.join(ADDONDATA, f'tv_basico_{timestamp}_{total}.m3u')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write(f'# Generado por {ADDON_NAME} - TV MODO BÁSICO\n')
            m3u.write(f'# Fecha: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            m3u.write(f'# Total canales: {total}\n\n')

            for idx, canal in enumerate(canales):
                if idx % 50 == 0:
                    percent = int((idx * 100) / total)
                    progress.update(percent, f"Procesando {idx+1}/{total}")
                    if progress.iscanceled():
                        m3u.write('# GENERACIÓN CANCELADA\n')
                        break

                name = limpiar_texto(canal.get('name', 'Sin título'))
                sid = canal.get('stream_id', '')
                logo = canal.get('stream_icon', '')
                cat_id = canal.get('category_id', '')
                group = cat_id_to_name.get(str(cat_id), 'TV')
                play_url = f"{dns}/{user}/{pw}/{sid}"

                m3u.write(f'#EXTINF:-1 tvg-id="{sid}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n')
                m3u.write(f'{play_url}\n\n')

        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'LISTA BÁSICA DE TV GENERADA\n\n{total} canales\ntv_basico_{timestamp}_{total}.m3u\n\n{ADDONDATA}')

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def generar_m3u_tv_completo():
    """Genera M3U completo de TV por canales seleccionados (con metadatos)"""
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    try:
        url_cats = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_categories"
        req = urllib.request.Request(url_cats)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data_cats = response.read().decode('utf-8')
        response.close()

        if not data_cats:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron categorías de TV')
            return

        categories = json.loads(data_cats)
        cat_names = ["TODOS LOS CANALES"]
        cat_ids = [0]
        for cat in categories:
            cat_names.append(cat.get('category_name', 'Sin categoría'))
            cat_ids.append(cat.get('category_id', ''))

        seleccion = xbmcgui.Dialog().multiselect('Selecciona CANALES de TV', cat_names)
        if not seleccion:
            return

        resumen = "Canales seleccionados:\n"
        for idx in seleccion[:10]:
            resumen += f"- {cat_names[idx]}\n"
        if len(seleccion) > 10:
            resumen += f"... y {len(seleccion)-10} más"

        if not xbmcgui.Dialog().yesno(ADDON_NAME, resumen, yeslabel='¿Continuar?', nolabel='¿Salir?'):
            return

        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_streams"
        req2 = urllib.request.Request(url)
        req2.add_header('User-Agent', 'Mozilla/5.0')
        response2 = urllib.request.urlopen(req2, timeout=60)
        data = response2.read().decode('utf-8')
        response2.close()

        if not data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudieron obtener canales')
            return

        all_channels = json.loads(data)

        if 0 in seleccion:
            canales_to_process = all_channels
            nombres_seleccion = ["TODOS LOS CANALES"]
        else:
            selected_ids = [cat_ids[i] for i in seleccion if i > 0]
            canales_to_process = [c for c in all_channels if str(c.get('category_id', '')) in [str(s) for s in selected_ids]]
            nombres_seleccion = [cat_names[i] for i in seleccion if i > 0]

        if not canales_to_process:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No hay canales en esas categorías')
            return

        generar_m3u_tv_con_metadatos(canales_to_process, dns, user, pw, nombres_seleccion, total=len(canales_to_process))

    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def generar_m3u_tv_con_metadatos(canales_list, dns, user, pw, seleccion_nombres, total=None):
    if total is None:
        total = len(canales_list)
    if total == 0:
        return

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    m3u_path = os.path.join(ADDONDATA, f'tv_completo_{timestamp}_{total}.m3u')

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Generando M3U de TV con {total} canales...")
    progress.update(0)

    try:
        url_cats = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_categories"
        req = urllib.request.Request(url_cats)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data_cats = response.read().decode('utf-8')
        response.close()
        cat_id_to_name = {}
        if data_cats:
            for cat in json.loads(data_cats):
                cat_id_to_name[str(cat.get('category_id', ''))] = cat.get('category_name', 'TV')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write(f'# Generado por {ADDON_NAME}\n')
            m3u.write(f'# Fecha: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            m3u.write(f'# Tipo: TV - COMPLETO\n')
            m3u.write(f'# Total: {total}\n#\n')
            for nombre in seleccion_nombres[:20]:
                m3u.write(f'# - {nombre}\n')
            m3u.write('#\n')
            m3u.write('# METADATOS INCLUIDOS:\n')
            m3u.write('# #EXTGENRE - Categoría\n')
            m3u.write('# #EXTLOGO - Logo\n')
            m3u.write('#\n\n')

            ok = 0
            errores = 0

            for idx, canal in enumerate(canales_list):
                if idx % 10 == 0:
                    percent = int((idx * 100) / total)
                    progress.update(percent, f"{idx+1}/{total}\nOK: {ok} | Error: {errores}")
                    if progress.iscanceled():
                        m3u.write('# GENERACIÓN CANCELADA\n')
                        break

                try:
                    name = limpiar_texto(canal.get('name', 'Sin título'))
                    sid = canal.get('stream_id', '')
                    logo = canal.get('stream_icon', '')
                    cat_id = canal.get('category_id', '')
                    group = cat_id_to_name.get(str(cat_id), 'TV')
                    play_url = f"{dns}/{user}/{pw}/{sid}"

                    m3u.write(f'#EXTINF:-1 tvg-id="{sid}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n')
                    if group:
                        m3u.write(f'#EXTGENRE:{group}\n')
                    if logo:
                        m3u.write(f'#EXTLOGO:{logo}\n')
                    m3u.write(f'{play_url}\n\n')
                    ok += 1

                except Exception as e:
                    errores += 1
                    continue

        progress.close()
        if ok > 0:
            xbmcgui.Dialog().notification(ADDON_NAME, f'{ok} canales de TV generados', icon, 5000)
            xbmcgui.Dialog().ok(ADDON_NAME, f'LISTA DE TV GENERADA\n\n{ok} canales procesados\n{errores} errores\n\n{os.path.basename(m3u_path)}\n\n{ADDONDATA}')

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

# ==================== GENERAR M3U PELÍCULAS ====================
def generar_m3u_basico():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Generando lista básica de películas...")
    progress.update(0)

    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_streams"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=60)
        data = response.read().decode('utf-8')
        response.close()

        if not data:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudieron obtener películas')
            return

        movies = json.loads(data)
        total = len(movies)

        with open(os.path.join(ADDONDATA, 'vod_categories.json'), 'r', encoding='utf-8') as f:
            categories = json.load(f)

        cat_id_to_name = {}
        for cat in categories:
            cat_id_to_name[str(cat.get('category_id', ''))] = cat.get('category_name', 'Películas')

        if not os.path.exists(ADDONDATA):
            os.makedirs(ADDONDATA)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        m3u_path = os.path.join(ADDONDATA, f'm3u_basico_{timestamp}_{total}.m3u')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write(f'# Generado por {ADDON_NAME} - MODO BÁSICO\n')
            m3u.write(f'# Fecha: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            m3u.write(f'# Total películas: {total}\n\n')

            for idx, movie in enumerate(movies):
                if idx % 50 == 0:
                    percent = int((idx * 100) / total)
                    progress.update(percent, f"Procesando {idx+1}/{total}")
                    if progress.iscanceled():
                        m3u.write('# GENERACIÓN CANCELADA\n')
                        break

                name = limpiar_texto(movie.get('name', 'Sin título'))
                sid = movie.get('stream_id', '')
                logo = movie.get('stream_icon', '')
                ext = movie.get('container_extension', 'mp4')
                play_url = f"{dns}/movie/{user}/{pw}/{sid}.{ext}"

                cat_ids = movie.get('category_ids', [])
                group = "Películas"
                if cat_ids:
                    group = cat_id_to_name.get(str(cat_ids[0]), "Películas")

                m3u.write(f'#EXTINF:-1 tvg-id="{sid}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n')
                m3u.write(f'{play_url}\n\n')

        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'LISTA BÁSICA DE PELÍCULAS GENERADA\n\n{total} películas\nm3u_basico_{timestamp}_{total}.m3u\n\n{ADDONDATA}')

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def generar_m3u_completo_canales():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    if not verificar_datos():
        return

    try:
        with open(os.path.join(ADDONDATA, 'vod_categories.json'), 'r', encoding='utf-8') as f:
            categories = json.load(f)

        cat_names = ["TODOS LOS CANALES"]
        cat_ids = [0]
        for cat in categories:
            cat_names.append(cat.get('category_name', 'Sin categoría'))
            cat_ids.append(cat.get('category_id', ''))

        seleccion = xbmcgui.Dialog().multiselect('Selecciona CANALES', cat_names)
        if not seleccion:
            return

        resumen = "Canales seleccionados:\n"
        for idx in seleccion[:10]:
            resumen += f"- {cat_names[idx]}\n"
        if len(seleccion) > 10:
            resumen += f"... y {len(seleccion)-10} más"

        if not xbmcgui.Dialog().yesno(ADDON_NAME, resumen, "¿Continuar?"):
            return

        with open(os.path.join(ADDONDATA, 'vod_streams.json'), 'r', encoding='utf-8') as f:
            all_movies = json.load(f)

        if 0 in seleccion:
            generar_m3u_con_metadatos(all_movies, dns, user, pw, "canales", ["TODOS LOS CANALES"], "TODOS LOS CANALES", total=len(all_movies))
        else:
            for idx in seleccion:
                if idx > 0:
                    canal_nombre = cat_names[idx]
                    canal_id = cat_ids[idx]
                    movies_to_process = [m for m in all_movies if str(canal_id) in [str(c) for c in m.get('category_ids', [])]]
                    if movies_to_process:
                        generar_m3u_con_metadatos(movies_to_process, dns, user, pw, "canales", [canal_nombre], canal_nombre, total=len(movies_to_process))

    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def generar_m3u_completo_generos():
    global GENEROS_CACHE
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    if not verificar_datos():
        return
    if GENEROS_CACHE is None:
        cargar_cache_generos()
    generos = GENEROS_CACHE
    if not generos:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron géneros')
        return

    opciones = [f"{g} ({len(generos[g])})" for g in sorted(generos.keys())]
    seleccion = xbmcgui.Dialog().multiselect('Selecciona GÉNEROS', opciones)
    if not seleccion:
        return

    generos_sel = [sorted(generos.keys())[i] for i in seleccion]

    resumen = "Géneros seleccionados:\n"
    for g in generos_sel[:10]:
        resumen += f"- {g} ({len(generos[g])})\n"
    if len(generos_sel) > 10:
        resumen += f"... y {len(generos_sel)-10} más"

    if not xbmcgui.Dialog().yesno(ADDON_NAME, resumen, "¿Continuar?"):
        return

    with open(os.path.join(ADDONDATA, 'vod_streams.json'), 'r', encoding='utf-8') as f:
        all_movies = json.load(f)

    with open(os.path.join(ADDONDATA, 'vod_categories.json'), 'r', encoding='utf-8') as f:
        categories = json.load(f)

    cat_id_to_name = {}
    for cat in categories:
        cat_id_to_name[str(cat.get('category_id', ''))] = cat.get('category_name', 'Películas')

    for genero in generos_sel:
        sids_incluir = set()
        for p in generos[genero]:
            sids_incluir.add(p['sid'])

        peliculas_por_canal = {}
        for movie in all_movies:
            if movie.get('stream_id') in sids_incluir:
                cat_ids = movie.get('category_ids', [])
                canal_nombre = "Películas"
                if cat_ids:
                    canal_nombre = cat_id_to_name.get(str(cat_ids[0]), "Películas")
                if canal_nombre not in peliculas_por_canal:
                    peliculas_por_canal[canal_nombre] = []
                peliculas_por_canal[canal_nombre].append(movie)

        for canal_nombre, peliculas_canal in peliculas_por_canal.items():
            if peliculas_canal:
                generar_m3u_con_metadatos(peliculas_canal, dns, user, pw, "generos", [genero], canal_nombre, total=len(peliculas_canal))

def generar_m3u_con_metadatos(movies_list, dns, user, pw, tipo, seleccion_nombres, grupo_nombre, total=None):
    if total is None:
        total = len(movies_list)
    if total == 0:
        return

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    grupo_limpio = re.sub(r'[<>:"/\\|?*]', '_', grupo_nombre) if grupo_nombre else "general"

    if tipo == "canales":
        nombre_base = f"canales_{grupo_limpio}"
    elif tipo == "generos":
        nombre_base = f"generos_{grupo_limpio}"
    else:
        nombre_base = "m3u_completo"

    m3u_path = os.path.join(ADDONDATA, f'{nombre_base}_{timestamp}_{total}.m3u')

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Generando M3U para {grupo_nombre}...")
    progress.update(0)

    try:
        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write(f'# Generado por {ADDON_NAME}\n')
            m3u.write(f'# Fecha: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            m3u.write(f'# Tipo: {tipo.upper()} - {grupo_nombre}\n')
            m3u.write(f'# Total: {total}\n#\n\n')

            ok = 0
            errores = 0

            for idx, movie in enumerate(movies_list):
                if idx % 5 == 0:
                    percent = int((idx * 100) / total)
                    progress.update(percent, f"{idx+1}/{total}\nOK: {ok} | Error: {errores}")
                    if progress.iscanceled():
                        m3u.write('# GENERACIÓN CANCELADA\n')
                        break

                try:
                    sid = movie.get('stream_id')
                    url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_info&vod_id={sid}"
                    req = urllib.request.Request(url)
                    req.add_header('User-Agent', 'Mozilla/5.0')
                    resp = urllib.request.urlopen(req, timeout=20)
                    data = resp.read().decode('utf-8')
                    resp.close()

                    if not data:
                        errores += 1
                        continue

                    detalle = json.loads(data)
                    info = detalle.get('info', {})
                    movie_data = detalle.get('movie_data', {})

                    name = limpiar_texto(info.get('name', movie.get('name', 'Sin título')))
                    year = info.get('releasedate', '')[:4]
                    plot = info.get('plot', '') or info.get('description', '')
                    director = info.get('director', '')
                    cast = info.get('cast', '') or info.get('actors', '')
                    genre = info.get('genre', '')
                    rating = info.get('rating', '')
                    duration = info.get('duration', '')
                    logo = info.get('cover_big', '') or info.get('movie_image', '') or movie.get('stream_icon', '')
                    ext = movie_data.get('container_extension', 'mp4')
                    play_url = f"{dns}/movie/{user}/{pw}/{sid}.{ext}"

                    titulo_mostrar = name
                    if year:
                        titulo_mostrar = f"{name} ({year})"

                    m3u.write(f'#EXTINF:-1 tvg-id="{sid}" tvg-name="{name}" tvg-logo="{logo}" group-title="{grupo_nombre}",{titulo_mostrar}\n')

                    if plot:
                        m3u.write(f'#EXTDESC:{plot.replace(chr(10), " ").strip()}\n')
                    if director:
                        m3u.write(f'#EXTDIRECTOR:{director}\n')
                    if cast:
                        m3u.write(f'#EXTCAST:{cast}\n')
                    if genre:
                        m3u.write(f'#EXTGENRE:{genre}\n')
                    if year:
                        m3u.write(f'#EXTYEAR:{year}\n')
                    if rating:
                        m3u.write(f'#EXTRATING:{rating}\n')
                    if duration:
                        m3u.write(f'#EXTRUNTIME:{duration}\n')

                    m3u.write(f'{play_url}\n\n')
                    ok += 1

                except Exception as e:
                    errores += 1
                    continue

        progress.close()
        if ok > 0:
            xbmcgui.Dialog().notification(ADDON_NAME, f'{ok} películas de {grupo_nombre}', icon, 3000)

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

# ==================== GENERAR M3U SERIES ====================
def generar_m3u_series_basico():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Generando lista básica de series...")
    progress.update(0)

    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=60)
        data = response.read().decode('utf-8')
        response.close()

        if not data:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudieron obtener series')
            return

        series_list = json.loads(data)
        total = len(series_list)

        with open(os.path.join(ADDONDATA, 'series_categories.json'), 'r', encoding='utf-8') as f:
            categories = json.load(f)

        cat_id_to_name = {}
        for cat in categories:
            cat_id_to_name[str(cat.get('category_id', ''))] = cat.get('category_name', 'Series')

        if not os.path.exists(ADDONDATA):
            os.makedirs(ADDONDATA)

        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        m3u_path = os.path.join(ADDONDATA, f'series_basico_{timestamp}_{total}.m3u')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write(f'# Generado por {ADDON_NAME} - SERIES MODO BÁSICO\n')
            m3u.write(f'# Fecha: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            m3u.write(f'# Total series: {total}\n\n')

            for idx, serie in enumerate(series_list):
                if idx % 50 == 0:
                    percent = int((idx * 100) / total)
                    progress.update(percent, f"Procesando {idx+1}/{total}")
                    if progress.iscanceled():
                        m3u.write('# GENERACIÓN CANCELADA\n')
                        break

                nombre = limpiar_texto(serie.get('name', 'Sin título'))
                serie_id = serie.get('series_id', '')
                logo = serie.get('cover', '') or serie.get('cover_big', '') or icon
                cat_id = serie.get('category_id', '')
                group = cat_id_to_name.get(str(cat_id), 'Series')
                play_url = f"{dns}/series/{user}/{pw}/{serie_id}"

                m3u.write(f'#EXTINF:-1 tvg-id="{serie_id}" tvg-name="{nombre}" tvg-logo="{logo}" group-title="{group}",{nombre}\n')
                m3u.write(f'{play_url}\n\n')

        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'LISTA BÁSICA DE SERIES GENERADA\n\n{total} series\nseries_basico_{timestamp}_{total}.m3u\n\n{ADDONDATA}')

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def generar_m3u_series_canales():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    try:
        with open(os.path.join(ADDONDATA, 'series_categories.json'), 'r', encoding='utf-8') as f:
            categories = json.load(f)

        cat_names = ["TODOS LOS CANALES"]
        cat_ids = [0]
        for cat in categories:
            cat_names.append(cat.get('category_name', 'Sin categoría'))
            cat_ids.append(cat.get('category_id', ''))

        seleccion = xbmcgui.Dialog().multiselect('Selecciona CANALES de Series', cat_names)
        if not seleccion:
            return

        resumen = "Canales seleccionados:\n"
        for idx in seleccion[:10]:
            resumen += f"- {cat_names[idx]}\n"
        if len(seleccion) > 10:
            resumen += f"... y {len(seleccion)-10} más"

        if not xbmcgui.Dialog().yesno(ADDON_NAME, resumen, "¿Continuar?"):
            return

        with open(os.path.join(ADDONDATA, 'series_list.json'), 'r', encoding='utf-8') as f:
            all_series = json.load(f)

        if 0 in seleccion:
            generar_m3u_series_con_metadatos(all_series, dns, user, pw, "canales", ["TODOS LOS CANALES"], "TODOS LOS CANALES", total=len(all_series))
        else:
            for idx in seleccion:
                if idx > 0:
                    canal_nombre = cat_names[idx]
                    canal_id = cat_ids[idx]
                    series_to_process = [s for s in all_series if str(s.get('category_id', '')) == str(canal_id)]
                    if series_to_process:
                        generar_m3u_series_con_metadatos(series_to_process, dns, user, pw, "canales", [canal_nombre], canal_nombre, total=len(series_to_process))

    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def generar_m3u_series_generos():
    global SERIES_GENEROS_CACHE
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    if SERIES_GENEROS_CACHE is None:
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, "Analizando géneros de series...")
        progress.update(0)
        try:
            with open(os.path.join(ADDONDATA, 'series_list.json'), 'r', encoding='utf-8') as f:
                all_series = json.load(f)

            generos = {}
            for idx, serie in enumerate(all_series[:500]):
                if idx % 50 == 0:
                    progress.update(int((idx * 100) / 500), f"Analizando {idx+1}/500")
                    if progress.iscanceled():
                        progress.close()
                        return
                try:
                    serie_id = serie.get('series_id', '')
                    url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
                    req = urllib.request.Request(url)
                    req.add_header('User-Agent', 'Mozilla/5.0')
                    resp = urllib.request.urlopen(req, timeout=15)
                    data = resp.read().decode('utf-8')
                    resp.close()
                    if data:
                        info = json.loads(data).get('info', {})
                        genre = info.get('genre', '')
                        if genre:
                            for g in [g.strip() for g in genre.split(',')]:
                                if g:
                                    if g not in generos:
                                        generos[g] = []
                                    generos[g].append({
                                        'serie_id': serie_id,
                                        'name': limpiar_texto(serie.get('name', '')),
                                        'logo': info.get('cover_big', '') or serie.get('cover', '') or icon,
                                        'year': info.get('releasedate', '')[:4],
                                        'rating': info.get('rating', '')
                                    })
                except:
                    continue

            progress.close()
            SERIES_GENEROS_CACHE = generos
        except Exception as e:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')
            return

    generos = SERIES_GENEROS_CACHE
    if not generos:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron géneros en las series')
        return

    opciones = [f"{g} ({len(generos[g])})" for g in sorted(generos.keys())]
    seleccion = xbmcgui.Dialog().multiselect('Selecciona GÉNEROS', opciones)
    if not seleccion:
        return

    generos_sel = [sorted(generos.keys())[i] for i in seleccion]

    resumen = "Géneros seleccionados:\n"
    for g in generos_sel[:10]:
        resumen += f"- {g} ({len(generos[g])})\n"
    if len(generos_sel) > 10:
        resumen += f"... y {len(generos_sel)-10} más"

    if not xbmcgui.Dialog().yesno(ADDON_NAME, resumen, "¿Continuar?"):
        return

    with open(os.path.join(ADDONDATA, 'series_list.json'), 'r', encoding='utf-8') as f:
        all_series = json.load(f)

    with open(os.path.join(ADDONDATA, 'series_categories.json'), 'r', encoding='utf-8') as f:
        categories = json.load(f)

    cat_id_to_name = {}
    for cat in categories:
        cat_id_to_name[str(cat.get('category_id', ''))] = cat.get('category_name', 'Series')

    for genero in generos_sel:
        series_ids = set()
        for s in generos[genero]:
            series_ids.add(s['serie_id'])

        series_por_canal = {}
        for serie in all_series:
            if str(serie.get('series_id', '')) in series_ids:
                cat_id = serie.get('category_id', '')
                canal_nombre = cat_id_to_name.get(str(cat_id), 'Series')
                if canal_nombre not in series_por_canal:
                    series_por_canal[canal_nombre] = []
                series_por_canal[canal_nombre].append(serie)

        for canal_nombre, series_canal in series_por_canal.items():
            if series_canal:
                generar_m3u_series_con_metadatos(series_canal, dns, user, pw, "generos", [genero], canal_nombre, total=len(series_canal))




def generar_m3u_series_con_metadatos(series_list, dns, user, pw, tipo, seleccion_nombres, grupo_nombre, total=None):
    if total is None:
        total = len(series_list)
    if total == 0:
        return

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    grupo_limpio = re.sub(r'[<>:"/\\|?*]', '_', grupo_nombre) if grupo_nombre else "general"

    if tipo == "canales":
        nombre_base = f"series_canales_{grupo_limpio}"
    elif tipo == "generos":
        nombre_base = f"series_generos_{grupo_limpio}"
    else:
        nombre_base = "series_completo"

    m3u_path = os.path.join(ADDONDATA, f'{nombre_base}_{timestamp}_{total}.m3u')

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Generando M3U para {grupo_nombre}...")
    progress.update(0)

    try:
        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write(f'# Generado por {ADDON_NAME}\n')
            m3u.write(f'# Fecha: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            m3u.write(f'# Tipo: SERIES - {tipo.upper()} - {grupo_nombre}\n')
            m3u.write(f'# Total: {total}\n#\n\n')

            ok = 0
            errores = 0

            for idx, serie in enumerate(series_list):
                if idx % 5 == 0:
                    percent = int((idx * 100) / total)
                    progress.update(percent, f"{idx+1}/{total}\nOK: {ok} | Error: {errores}")
                    if progress.iscanceled():
                        m3u.write('# GENERACIÓN CANCELADA\n')
                        break

                try:
                    serie_id = serie.get('series_id')
                    url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
                    req = urllib.request.Request(url)
                    req.add_header('User-Agent', 'Mozilla/5.0')
                    resp = urllib.request.urlopen(req, timeout=20)
                    data = resp.read().decode('utf-8')
                    resp.close()

                    if not data:
                        errores += 1
                        continue

                    detalle = json.loads(data)
                    info = detalle.get('info', {})

                    name = limpiar_texto(info.get('name', serie.get('name', 'Sin título')))
                    year = info.get('releasedate', '')[:4]
                    plot = info.get('plot', '') or info.get('description', '')
                    director = info.get('director', '')
                    cast = info.get('cast', '') or info.get('actors', '')
                    genre = info.get('genre', '')
                    rating = info.get('rating', '')
                    logo = info.get('cover_big', '') or info.get('cover', '') or serie.get('cover', '') or icon
                    play_url = f"{dns}/series/{user}/{pw}/{serie_id}"

                    titulo_mostrar = name
                    if year:
                        titulo_mostrar = f"{name} ({year})"

                    m3u.write(f'#EXTINF:-1 tvg-id="{serie_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{grupo_nombre}",{titulo_mostrar}\n')

                    if plot:
                        m3u.write(f'#EXTDESC:{plot.replace(chr(10), " ").strip()}\n')
                    if director:
                        m3u.write(f'#EXTDIRECTOR:{director}\n')
                    if cast:
                        m3u.write(f'#EXTCAST:{cast}\n')
                    if genre:
                        m3u.write(f'#EXTGENRE:{genre}\n')
                    if year:
                        m3u.write(f'#EXTYEAR:{year}\n')
                    if rating:
                        m3u.write(f'#EXTRATING:{rating}\n')

                    m3u.write(f'{play_url}\n\n')
                    ok += 1

                except Exception as e:
                    errores += 1
                    continue

        progress.close()
        if ok > 0:
            xbmcgui.Dialog().notification(ADDON_NAME, f'{ok} series de {grupo_nombre}', icon, 3000)

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def generar_m3u_series_con_temporadas(series_list, dns, user, pw, grupo_nombre, total=None):
    """
    Genera un archivo M3U para una lista de series, incluyendo todas las temporadas y episodios.
    Esto es más completo y lento, pero permite acceder a cada episodio individualmente.
    """
    if total is None:
        total = len(series_list)
    if total == 0:
        return

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    grupo_limpio = re.sub(r'[<>:"/\\|?*]', '_', grupo_nombre) if grupo_nombre else "general"
    m3u_path = os.path.join(ADDONDATA, f'series_completas_{grupo_limpio}_{timestamp}_{total}.m3u')

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Generando M3U completo para {grupo_nombre}...")
    progress.update(0)

    try:
        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write(f'# Generado por {ADDON_NAME}\n')
            m3u.write(f'# Fecha: {datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
            m3u.write(f'# Tipo: SERIES COMPLETAS - {grupo_nombre}\n')
            m3u.write(f'# Total series: {total}\n#\n\n')

            series_ok = 0
            errores = 0

            for idx, serie in enumerate(series_list):
                if idx % 5 == 0:
                    percent = int((idx * 100) / total) if total > 0 else 0
                    progress.update(percent, f"Procesando serie {idx+1}/{total}\nOK: {series_ok} | Error: {errores}")
                    if progress.iscanceled():
                        m3u.write('# GENERACIÓN CANCELADA\n')
                        break

                try:
                    serie_id = serie.get('series_id')
                    # Obtener información de la serie (temporadas y episodios)
                    url_info = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
                    req = urllib.request.Request(url_info)
                    req.add_header('User-Agent', 'Mozilla/5.0')
                    resp = urllib.request.urlopen(req, timeout=30)
                    data = resp.read().decode('utf-8')
                    resp.close()

                    if not data:
                        errores += 1
                        continue

                    info_serie = json.loads(data)
                    info = info_serie.get('info', {})
                    nombre_serie = limpiar_texto(info.get('name', serie.get('name', 'Sin título')))
                    year = info.get('releasedate', '')[:4]
                    plot = info.get('plot', '') or info.get('description', '')
                    logo = info.get('cover_big', '') or info.get('cover', '') or serie.get('cover', '') or icon

                    episodios_por_temp = info_serie.get('episodes', {})
                    temporadas = sorted([int(t) for t in episodios_por_temp.keys() if t.isdigit()])

                    # Escribir cabecera de la serie
                    titulo_serie = f"{nombre_serie} ({year})" if year else nombre_serie
                    m3u.write(f'#EXTINF:-1 tvg-id="{serie_id}" tvg-name="{nombre_serie}" tvg-logo="{logo}" group-title="{grupo_nombre}",{titulo_serie}\n')
                    if plot:
                        m3u.write(f'#EXTDESC:{plot.replace(chr(10), " ").strip()}\n')
                    m3u.write(f'#EXTGRP:{grupo_nombre}\n')

                    # Por cada temporada y episodio, escribir una entrada
                    for temp in temporadas:
                        episodios = episodios_por_temp[str(temp)]
                        for ep in episodios:
                            titulo_ep = limpiar_texto(ep.get('title', f'Episodio {ep.get("episode_num", "")}'))
                            num_ep = ep.get('episode_num', '')
                            if num_ep:
                                titulo_ep = f"{num_ep} - {titulo_ep}"
                            ep_id = ep.get('id', '')
                            contenedor = ep.get('container_extension', 'mp4')
                            play_url = f"{dns}/series/{user}/{pw}/{ep_id}.{contenedor}"

                            # Línea del episodio
                            nombre_episodio = f"{nombre_serie} - Temporada {temp} - {titulo_ep}"
                            m3u.write(f'#EXTINF:-1 tvg-id="{ep_id}" tvg-name="{nombre_episodio}" tvg-logo="{logo}" group-title="{grupo_nombre}",{nombre_episodio}\n')
                            m3u.write(f'{play_url}\n')
                        m3u.write('\n')  # separador entre temporadas

                    series_ok += 1

                except Exception as e:
                    xbmc.log(f'IPTVXC: Error procesando serie: {e}', xbmc.LOGERROR)
                    errores += 1
                    continue

        progress.close()
        if series_ok > 0:
            xbmcgui.Dialog().notification(ADDON_NAME, f'Generadas {series_ok} series completas', icon, 5000)
            xbmcgui.Dialog().ok(ADDON_NAME, f'ARCHIVO M3U COMPLETO GENERADO\n\nSeries: {series_ok}\nErrores: {errores}\n\n{os.path.basename(m3u_path)}\n\n{ADDONDATA}')
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

# ==================== GENERAR M3U SERIES COMPLETO POR CANALES (CON TEMPORADAS) ====================
def generar_m3u_series_canales_completo(canal_especifico_nombre=None, canal_especifico_id=None):
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    try:
        with open(os.path.join(ADDONDATA, 'series_categories.json'), 'r', encoding='utf-8') as f:
            categories = json.load(f)

        with open(os.path.join(ADDONDATA, 'series_list.json'), 'r', encoding='utf-8') as f:
            all_series = json.load(f)

        if canal_especifico_nombre and canal_especifico_id:
            canales_a_procesar = [(canal_especifico_nombre, canal_especifico_id)]
        else:
            cat_names = []
            cat_ids = []
            for cat in categories:
                cat_id = cat.get('category_id', '')
                cat_name = cat.get('category_name', 'Sin categoría')
                num_series = len([s for s in all_series if str(s.get('category_id', '')) == str(cat_id)])
                cat_names.append(f"{cat_name} [{num_series} series]")
                cat_ids.append(cat_id)

            total_series = len(all_series)
            cat_names.insert(0, f"TODOS LOS CANALES [{total_series} series]")
            cat_ids.insert(0, 0)

            seleccion = xbmcgui.Dialog().multiselect('Selecciona CANALES de Series (con temporadas)', cat_names)
            if not seleccion:
                return

            resumen = "Canales seleccionados:\n"
            for idx in seleccion[:10]:
                resumen += f"- {cat_names[idx]}\n"
            if len(seleccion) > 10:
                resumen += f"... y {len(seleccion)-10} más"

            if not xbmcgui.Dialog().yesno(ADDON_NAME, resumen, yeslabel='¿Continuar?', nolabel='¿Salir?'):
                return

            canales_a_procesar = []
            if 0 in seleccion:
                for idx, cat in enumerate(categories):
                    canales_a_procesar.append((categories[idx].get('category_name', 'Sin categoría'), categories[idx].get('category_id', '')))
            else:
                for idx in seleccion:
                    if idx > 0:
                        canales_a_procesar.append((categories[idx-1].get('category_name', 'Sin categoría'), categories[idx-1].get('category_id', '')))

        for canal_nombre, canal_id in canales_a_procesar:
            series_del_canal = [s for s in all_series if str(s.get('category_id', '')) == str(canal_id)]
            if not series_del_canal:
                xbmcgui.Dialog().notification(ADDON_NAME, f'No hay series en {canal_nombre}', icon, 3000)
                continue

            generar_m3u_series_con_temporadas(series_del_canal, dns, user, pw, canal_nombre, total=len(series_del_canal))

    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

# ==================== INFORMACIÓN CUENTA ====================
def account_info():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales en Ajustes Servidor')
        return
    
    # Validar que la URL tenga esquema http o https
    if not dns.startswith('http://') and not dns.startswith('https://'):
        xbmcgui.Dialog().ok(ADDON_NAME, f'La URL del servidor no es válida:\n{dns}\n\nDebe comenzar con http:// o https://')
        return
    
    try:
        # Usar panel_api.php (más fiable que player_api.php para info de cuenta)
        url = f"{dns}/panel_api.php?username={user}&password={pw}"
        xbmc.log(f'IPTVXC: Consultando información de cuenta: {url}', xbmc.LOGINFO)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read().decode('utf-8')
        response.close()
        
        if not data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se recibió respuesta del servidor')
            return
            
        parse = json.loads(data)
        ui = parse.get('user_info', {})
        
        if not ui:
            # Intentar con player_api.php como respaldo
            url2 = f"{dns}/player_api.php?username={user}&password={pw}"
            req2 = urllib.request.Request(url2)
            req2.add_header('User-Agent', 'Mozilla/5.0')
            response2 = urllib.request.urlopen(req2, timeout=15)
            data2 = response2.read().decode('utf-8')
            response2.close()
            if data2:
                parse2 = json.loads(data2)
                ui = parse2.get('user_info', {})
        
        if not ui:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo obtener información de la cuenta.\nVerifica que las credenciales sean correctas.')
            return
        
        expiry = ui.get('exp_date', '')
        if expiry and expiry != '0':
            try:
                expiry = datetime.datetime.fromtimestamp(int(expiry)).strftime('%d/%m/%Y')
            except:
                expiry = 'Fecha inválida'
        else:
            expiry = 'Ilimitado'
        
        status = ui.get('status', '')
        if status == 'Active':
            status = 'Activo'
        elif status == 'Trial':
            status = 'Prueba'
        elif status == 'Expired':
            status = 'Expirado'
        
        servidor = dns.replace('http://', '').replace('https://', '')
        
        texto = f"SERVIDOR ACTIVO: {servidor}\n\n"
        texto += f"USUARIO: {ui.get('username', user)}\n"
        texto += f"CONTRASEÑA: {ui.get('password', '*' * len(pw))}\n"
        texto += f"EXPIRA: {expiry}\n"
        texto += f"ESTADO: {status}\n"
        texto += f"CONEXIONES: {ui.get('active_cons', '0')} / {ui.get('max_connections', 'Ilimitado')}\n"
        texto += f"IP LOCAL: {get_local_ip()}\n"
        texto += f"IP EXTERNA: {get_external_ip()}"
        
        xbmcgui.Dialog().textviewer("Información de la Cuenta", texto)
        
    except urllib.error.URLError as e:
        xbmc.log(f'IPTVXC: Error de conexión en account_info: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error de conexión:\n{str(e)}\n\nVerifica que el servidor está accesible y la URL es correcta.')
    except json.JSONDecodeError as e:
        xbmc.log(f'IPTVXC: Error decoding JSON: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, f'El servidor no devolvió datos JSON válidos.\nRevisa tus credenciales.')
    except Exception as e:
        xbmc.log(f'IPTVXC: Error en account_info: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error inesperado:\n{str(e)[:100]}')

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 0))
        return s.getsockname()[0]
    except:
        return 'No disponible'

def get_external_ip():
    try:
        url = "https://api.ipify.org/?format=json"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=5)
        data = response.read().decode('utf-8')
        response.close()
        return json.loads(data).get('ip', 'No disponible')
    except:
        return 'No disponible'

# ==================== TV EN VIVO ====================
def live_tv():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    opciones = [
        'Ver categorías',
        'Buscar canales'
    ]
    seleccion = xbmcgui.Dialog().select('TV en Vivo', opciones)
    if seleccion == -1:
        return
    elif seleccion == 0:
        live_categorias()
    elif seleccion == 1:
        buscar_canales_tv()

def live_categorias():
    dns, user, pw = get_creds()
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_categories"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read().decode('utf-8')
        response.close()
        if data:
            for cat in json.loads(data):
                name = limpiar_texto(cat.get('category_name', 'Sin nombre'))
                cat_id = cat.get('category_id', '')
                url_cat = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_streams&category_id={cat_id}"
                add_item(name, url_cat, 2)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:80]}')

def buscar_canales_tv():
    kb = xbmc.Keyboard('', 'Buscar canal de TV\nEscribe el nombre del canal', True)
    kb.setHeading('Buscar canal de TV')
    kb.setHiddenInput(False)
    kb.doModal()
    if not kb.isConfirmed():
        return
    texto = kb.getText().strip()
    if not texto or len(texto) < 2:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Ingresa al menos 2 caracteres')
        return

    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Buscando canales: {texto}...")
    progress.update(0)

    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_live_streams"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=30)
        data = response.read().decode('utf-8')
        response.close()

        if not data:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron canales')
            return

        canales = json.loads(data)
        resultados = []
        for canal in canales:
            nombre = limpiar_texto(canal.get('name', '')).lower()
            if texto.lower() in nombre:
                resultados.append(canal)

        progress.close()

        if not resultados:
            xbmcgui.Dialog().ok(ADDON_NAME, f'No se encontraron canales con "{texto}"')
            return

        xbmcgui.Dialog().notification(ADDON_NAME, f'Encontrados {len(resultados)} canales', icon, 3000)

        for canal in resultados:
            name = limpiar_texto(canal.get('name', 'Sin nombre'))
            sid = canal.get('stream_id', '')
            logo = canal.get('stream_icon', icon)
            play_url = f"{dns}/{user}/{pw}/{sid}"

            plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(play_url) + "&mode=4&name=" + urllib.parse.quote_plus(name) + "&iconimage=" + urllib.parse.quote_plus(logo)
            li = xbmcgui.ListItem(name)
            li.setArt({'icon': logo, 'thumb': logo})
            li.setProperty('fanart_image', fanart)
            li.setProperty('IsPlayable', 'true')

            cm = []
            if es_favorito(play_url):
                cm.append(('❌ Eliminar de Favoritos', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)})'))
            else:
                cm.append(('Añadir a Favoritos menu', f'RunPlugin({sys.argv[0]}?mode=33&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)}&iconimage={urllib.parse.quote_plus(logo)})'))
            cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?url={urllib.parse.quote_plus(play_url)}&mode=200&name={urllib.parse.quote_plus(name)})'))
            li.addContextMenuItems(cm)

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def live_streams(url):
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read().decode('utf-8')
        response.close()
        if data:
            dns, user, pw = get_creds()
            for stream in json.loads(data):
                name = limpiar_texto(stream.get('name', 'Sin nombre'))
                sid = stream.get('stream_id', '')
                logo = stream.get('stream_icon', icon)
                play_url = f"{dns}/{user}/{pw}/{sid}"
                plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(play_url) + "&mode=4&name=" + urllib.parse.quote_plus(name) + "&iconimage=" + urllib.parse.quote_plus(logo)
                li = xbmcgui.ListItem(name)
                li.setArt({'icon': logo, 'thumb': logo})
                li.setProperty('fanart_image', fanart)
                li.setProperty('IsPlayable', 'true')
                cm = []
                
                if es_favorito(play_url):
                    cm.append(('❌ Eliminar de Favoritos', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)})'))
                else:
                    cm.append(('Añadir a Favoritos menu', f'RunPlugin({sys.argv[0]}?mode=33&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)}&iconimage={urllib.parse.quote_plus(logo)})'))
                cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?url={urllib.parse.quote_plus(play_url)}&mode=200&name={urllib.parse.quote_plus(name)})'))
                li.addContextMenuItems(cm)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:80]}')

# ==================== GUÍA TV ====================
def tv_guide():
    xbmc.executebuiltin('ActivateWindow(TVGuide)')

# ==================== PELÍCULAS ====================
def movies():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Cargando canales de películas...")
    progress.update(0)

    try:
        progress.update(10, "Obteniendo lista de películas...")
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_streams"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=60)
        data = response.read().decode('utf-8')
        response.close()

        if data:
            if not os.path.exists(ADDONDATA):
                os.makedirs(ADDONDATA)
            with open(os.path.join(ADDONDATA, 'vod_streams.json'), 'w', encoding='utf-8') as f:
                f.write(data)

        progress.update(30, "Obteniendo categorías...")
        url_cats = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_categories"
        req2 = urllib.request.Request(url_cats)
        req2.add_header('User-Agent', 'Mozilla/5.0')
        response2 = urllib.request.urlopen(req2, timeout=15)
        data_cats = response2.read().decode('utf-8')
        response2.close()

        if data_cats:
            with open(os.path.join(ADDONDATA, 'vod_categories.json'), 'w', encoding='utf-8') as f:
                f.write(data_cats)

        if data_cats:
            categories = json.loads(data_cats)
            for cat in categories:
                nombre_canal = limpiar_texto(cat.get('category_name', 'Sin nombre'))
                cat_id = cat.get('category_id', '')
                url_cat = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_streams&category_id={cat_id}"
                add_item(nombre_canal, url_cat, 9, icon, '', nombre_canal)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        progress.close()

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def movie_list(url, canal_nombre=""):
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read().decode('utf-8')
        response.close()
        if data:
            dns, user, pw = get_creds()
            for movie in json.loads(data):
                nombre_peli = limpiar_texto(movie.get('name', 'Sin nombre'))
                sid = movie.get('stream_id', '')
                logo = movie.get('stream_icon', icon)
                ext = movie.get('container_extension', 'mp4')
                play_url = f"{dns}/movie/{user}/{pw}/{sid}.{ext}"

                nombre_con_canal = f"[{canal_nombre}] {nombre_peli}" if canal_nombre else nombre_peli

                plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(play_url) + "&mode=4&name=" + urllib.parse.quote_plus(nombre_con_canal) + "&iconimage=" + urllib.parse.quote_plus(logo) + "&canal=" + urllib.parse.quote_plus(canal_nombre)
                li = xbmcgui.ListItem(nombre_peli)
                li.setArt({'icon': logo, 'thumb': logo})
                li.setProperty('fanart_image', fanart)
                li.setProperty('IsPlayable', 'true')

# Opción de favoritos del addon (si tienes mode=33)
                cm = []
                if es_favorito(play_url):
                    cm.append(('❌ Eliminar de Favoritos Iptv', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(nombre_con_canal)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
                else:
                    cm.append(('Añadir a Favoritos Iptv', f'RunPlugin({sys.argv[0]}?mode=33&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(nombre_con_canal)}&iconimage={urllib.parse.quote_plus(logo)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
# Descargar                
                    cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?url={urllib.parse.quote_plus(play_url)}&mode=200&name={urllib.parse.quote_plus(nombre_con_canal)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
                
                cm.append(('Opciones Información', f'RunPlugin({sys.argv[0]}?url={sid}&mode=201&name={urllib.parse.quote_plus(nombre_peli)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
                li.addContextMenuItems(cm)

                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:80]}')

# ==================== BUSCADOR ====================
def buscador():
    opciones = [
        'PELÍCULAS',
        'SERIES',
        'TV EN VIVO'
    ]
    seleccion = xbmcgui.Dialog().select('Buscador', opciones)
    if seleccion == -1:
        return
    elif seleccion == 0:
        buscador_peliculas()
    elif seleccion == 1:
        buscador_series()
    elif seleccion == 2:
        buscar_canales_tv()

def buscador_peliculas():
    opciones = [
        'BUSCAR POR GÉNEROS',
        'BUSCADOR GENERAL (Título)',
        'BUSCAR POR TÍTULO'
    ]
    seleccion = xbmcgui.Dialog().select('Buscador - Películas', opciones)
    if seleccion == -1:
        return
    elif seleccion == 0:
        buscar_por_generos()
    elif seleccion == 1:
        buscador_general()
    elif seleccion == 2:
        buscar_por_titulo()

def buscador_series():
    opciones = [
        'BUSCAR POR TÍTULO',
        'BUSCAR POR GÉNEROS',
        'BUSCADOR GENERAL (Título y Sinopsis)'
    ]
    seleccion = xbmcgui.Dialog().select('Buscador - Series', opciones)
    if seleccion == -1:
        return
    elif seleccion == 0:
        buscar_series_por_titulo()
    elif seleccion == 1:
        buscar_series_por_generos()
    elif seleccion == 2:
        buscar_series_general()

# ==================== BUSCADOR PELÍCULAS ====================
def buscador_general():
    kb = xbmc.Keyboard('', 'Buscador general\nBusca en Películas\nEscribe el texto a buscar', True)
    kb.setHeading('Buscador general')
    kb.setHiddenInput(False)
    kb.doModal()
    if not kb.isConfirmed():
        return
    texto = kb.getText().strip()
    if not texto or len(texto) < 2:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Ingresa al menos 2 caracteres')
        return
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    if not verificar_datos():
        return
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Buscando: {texto}...")
    progress.update(0)
    try:
        with open(os.path.join(ADDONDATA, 'vod_streams.json'), 'r', encoding='utf-8') as f:
            all_movies = json.load(f)
        resultados = []
        for movie in all_movies:
            nombre = limpiar_texto(movie.get('name', '')).lower()
            if texto.lower() in nombre:
                resultados.append(movie)
        progress.close()
        if not resultados:
            xbmcgui.Dialog().ok(ADDON_NAME, f'No se encontraron resultados para:\n\n"{texto}"')
            return
        xbmcgui.Dialog().notification(ADDON_NAME, f'Encontradas {len(resultados)} películas', icon, 3000)
        for movie in resultados:
            name = limpiar_texto(movie.get('name', 'Sin nombre'))
            sid = movie.get('stream_id', '')
            logo = movie.get('stream_icon', icon)
            ext = movie.get('container_extension', 'mp4')
            play_url = f"{dns}/movie/{user}/{pw}/{sid}.{ext}"
            plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(play_url) + "&mode=4&name=" + urllib.parse.quote_plus(name) + "&iconimage=" + urllib.parse.quote_plus(logo)
            li = xbmcgui.ListItem(name)
            li.setArt({'icon': logo, 'thumb': logo})
            li.setProperty('fanart_image', fanart)
            li.setProperty('IsPlayable', 'true')
            cm = []
            if es_favorito(play_url):
                cm.append(('❌ Eliminar de Favoritos', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)})'))
            else:
                cm.append(('Añadir a Favoritos Iptv', f'RunPlugin({sys.argv[0]}?mode=33&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)}&iconimage={urllib.parse.quote_plus(logo)})'))
            cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?url={urllib.parse.quote_plus(play_url)}&mode=200&name={urllib.parse.quote_plus(name)})'))
            cm.append(('Opciones Información', f'RunPlugin({sys.argv[0]}?url={sid}&mode=201&name={urllib.parse.quote_plus(name)})'))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def buscar_por_generos():
    global GENEROS_CACHE
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    if not verificar_datos():
        return
    if GENEROS_CACHE is None:
        cargar_cache_generos()
    generos = GENEROS_CACHE
    if not generos:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron géneros')
        return
    opciones = [f"{g} ({len(generos[g])})" for g in sorted(generos.keys())]
    seleccion = xbmcgui.Dialog().select('Selecciona género', opciones)
    if seleccion < 0:
        return
    genero_sel = sorted(generos.keys())[seleccion]
    peliculas = generos[genero_sel]
    for p in peliculas:
        nombre = limpiar_texto(p['name'])
        if p['year']:
            nombre += f" ({p['year']})"
        if p['rating']:
            try:
                r = float(p['rating'])
                estrellas = '⭐' * min(5, int(r))
                if estrellas:
                    nombre += f" {estrellas}"
            except:
                pass
        play_url = f"{dns}/movie/{user}/{pw}/{p['sid']}.mp4"
        plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(play_url) + "&mode=4&name=" + urllib.parse.quote_plus(nombre) + "&iconimage=" + urllib.parse.quote_plus(p['logo']) + "&canal=" + urllib.parse.quote_plus(genero_sel)
        li = xbmcgui.ListItem(nombre)
        li.setArt({'icon': p['logo'], 'thumb': p['logo']})
        li.setProperty('fanart_image', fanart)
        li.setProperty('IsPlayable', 'true')
        cm = []
        if es_favorito(play_url):
            cm.append(('❌ Eliminar de Favoritos', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(nombre)}&canal={urllib.parse.quote_plus(genero_sel)})'))
        else:
            cm.append(('Añadir a Favoritos Iptv', f'RunPlugin({sys.argv[0]}?mode=33&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(nombre)}&iconimage={urllib.parse.quote_plus(p["logo"])}&canal={urllib.parse.quote_plus(genero_sel)})'))
        cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?url={urllib.parse.quote_plus(play_url)}&mode=200&name={urllib.parse.quote_plus(nombre)}&canal={urllib.parse.quote_plus(genero_sel)})'))
        cm.append(('Opciones Información', f'RunPlugin({sys.argv[0]}?url={p["sid"]}&mode=201&name={urllib.parse.quote_plus(p["name"])}&canal={urllib.parse.quote_plus(genero_sel)})'))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def cargar_cache_generos():
    global GENEROS_CACHE
    dns, user, pw = get_creds()
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Analizando géneros...")
    progress.update(0)
    try:
        with open(os.path.join(ADDONDATA, 'vod_streams.json'), 'r', encoding='utf-8') as f:
            all_movies = json.load(f)
        generos = {}
        for idx, movie in enumerate(all_movies[:500]):
            if idx % 50 == 0:
                progress.update(int((idx * 100) / 500), f"Analizando {idx+1}/500")
                if progress.iscanceled():
                    progress.close()
                    return
            try:
                sid = movie.get('stream_id')
                url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_info&vod_id={sid}"
                req = urllib.request.Request(url)
                req.add_header('User-Agent', 'Mozilla/5.0')
                resp = urllib.request.urlopen(req, timeout=15)
                data = resp.read().decode('utf-8')
                resp.close()
                if data:
                    info = json.loads(data).get('info', {})
                    genre = info.get('genre', '')
                    if genre:
                        for g in [g.strip() for g in genre.split(',')]:
                            if g:
                                if g not in generos:
                                    generos[g] = []
                                generos[g].append({
                                    'sid': sid,
                                    'name': limpiar_texto(movie.get('name', '')),
                                    'logo': info.get('cover_big', '') or movie.get('stream_icon', ''),
                                    'year': info.get('releasedate', '')[:4],
                                    'rating': info.get('rating', ''),
                                    'plot': info.get('plot', '')[:200]
                                })
            except:
                continue
        progress.close()
        GENEROS_CACHE = generos
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def buscar_por_titulo():
    kb = xbmc.Keyboard('', 'Buscar por título\nEscribe el nombre de la película', True)
    kb.setHeading('Buscar por título')
    kb.setHiddenInput(False)
    kb.doModal()
    if not kb.isConfirmed():
        return
    texto = kb.getText().strip()
    if not texto or len(texto) < 2:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Ingresa al menos 2 caracteres')
        return
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    if not verificar_datos():
        return
    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Buscando: {texto}...")
    progress.update(0)
    try:
        with open(os.path.join(ADDONDATA, 'vod_streams.json'), 'r', encoding='utf-8') as f:
            all_movies = json.load(f)
        resultados = []
        for movie in all_movies:
            nombre = limpiar_texto(movie.get('name', '')).lower()
            if texto.lower() in nombre:
                resultados.append(movie)
        progress.close()
        if not resultados:
            xbmcgui.Dialog().ok(ADDON_NAME, f'No se encontraron resultados para:\n\n"{texto}"')
            return
        xbmcgui.Dialog().notification(ADDON_NAME, f'Encontradas {len(resultados)} películas', icon, 3000)
        for movie in resultados:
            name = limpiar_texto(movie.get('name', 'Sin nombre'))
            sid = movie.get('stream_id', '')
            logo = movie.get('stream_icon', icon)
            ext = movie.get('container_extension', 'mp4')
            play_url = f"{dns}/movie/{user}/{pw}/{sid}.{ext}"
            plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(play_url) + "&mode=4&name=" + urllib.parse.quote_plus(name) + "&iconimage=" + urllib.parse.quote_plus(logo)
            li = xbmcgui.ListItem(name)
            li.setArt({'icon': logo, 'thumb': logo})
            li.setProperty('fanart_image', fanart)
            li.setProperty('IsPlayable', 'true')
            cm = []
            if es_favorito(play_url):
                cm.append(('❌ Eliminar de Favoritos', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)})'))
            else:
                cm.append(('Añadir a Favoritos Iptv', f'RunPlugin({sys.argv[0]}?mode=33&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(name)}&iconimage={urllib.parse.quote_plus(logo)})'))
            cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?url={urllib.parse.quote_plus(play_url)}&mode=200&name={urllib.parse.quote_plus(name)})'))
            cm.append(('Opciones Información', f'RunPlugin({sys.argv[0]}?url={sid}&mode=201&name={urllib.parse.quote_plus(name)})'))
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

# ==================== BUSCADOR SERIES ====================
def buscar_series_por_titulo():
    kb = xbmc.Keyboard('', 'Buscar serie por título\nEscribe el nombre de la serie', True)
    kb.setHeading('Buscar serie por título')
    kb.setHiddenInput(False)
    kb.doModal()
    if not kb.isConfirmed():
        return
    texto = kb.getText().strip()
    if not texto or len(texto) < 2:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Ingresa al menos 2 caracteres')
        return

    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Buscando series: {texto}...")
    progress.update(0)

    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=30)
        data = response.read().decode('utf-8')
        response.close()

        if not data:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron series')
            return

        series_list = json.loads(data)
        resultados = []

        for serie in series_list:
            nombre = limpiar_texto(serie.get('name', '')).lower()
            if texto.lower() in nombre:
                resultados.append(serie)

        progress.close()

        if not resultados:
            xbmcgui.Dialog().ok(ADDON_NAME, f'No se encontraron series para:\n\n"{texto}"')
            return

        xbmcgui.Dialog().notification(ADDON_NAME, f'Encontradas {len(resultados)} series', icon, 3000)

        for serie in resultados:
            nombre = limpiar_texto(serie.get('name', 'Sin nombre'))
            serie_id = serie.get('series_id', '')
            logo = serie.get('cover', '') or serie.get('cover_big', '') or icon
            year = serie.get('releaseDate', '')[:4]
            rating = serie.get('rating', '')

            nombre_mostrar = nombre
            if year:
                nombre_mostrar += f" ({year})"
            if rating:
                try:
                    r = float(rating)
                    estrellas = '⭐' * min(5, int(r))
                    if estrellas:
                        nombre_mostrar += f" {estrellas}"
                except:
                    pass

            plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}") + "&mode=20&name=" + urllib.parse.quote_plus(nombre_mostrar) + "&iconimage=" + urllib.parse.quote_plus(logo) + "&serie_id=" + str(serie_id)
            li = xbmcgui.ListItem(nombre_mostrar)
            li.setArt({'icon': logo, 'thumb': logo})
            li.setProperty('fanart_image', fanart)

            cm = []
            cm.append(('Información', f'RunPlugin({sys.argv[0]}?url={serie_id}&mode=202&name={urllib.parse.quote_plus(nombre)})'))
            li.addContextMenuItems(cm)

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def buscar_series_por_generos():
    global SERIES_GENEROS_CACHE
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Analizando géneros de series...")
    progress.update(0)

    try:
        if SERIES_GENEROS_CACHE is None:
            url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series"
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0')
            response = urllib.request.urlopen(req, timeout=30)
            data = response.read().decode('utf-8')
            response.close()

            if not data:
                progress.close()
                xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron series')
                return

            series_list = json.loads(data)
            generos = {}

            for idx, serie in enumerate(series_list[:500]):
                if idx % 50 == 0:
                    progress.update(int((idx * 100) / 500), f"Analizando {idx+1}/500")
                    if progress.iscanceled():
                        progress.close()
                        return
                try:
                    serie_id = serie.get('series_id', '')
                    url_info = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
                    req2 = urllib.request.Request(url_info)
                    req2.add_header('User-Agent', 'Mozilla/5.0')
                    resp2 = urllib.request.urlopen(req2, timeout=15)
                    data2 = resp2.read().decode('utf-8')
                    resp2.close()
                    if data2:
                        info = json.loads(data2).get('info', {})
                        genre = info.get('genre', '')
                        if genre:
                            for g in [g.strip() for g in genre.split(',')]:
                                if g:
                                    if g not in generos:
                                        generos[g] = []
                                    generos[g].append({
                                        'serie_id': serie_id,
                                        'name': limpiar_texto(serie.get('name', '')),
                                        'logo': info.get('cover_big', '') or serie.get('cover', '') or icon,
                                        'year': info.get('releasedate', '')[:4],
                                        'rating': info.get('rating', '')
                                    })
                except:
                    continue

            progress.close()
            SERIES_GENEROS_CACHE = generos
        else:
            generos = SERIES_GENEROS_CACHE
            progress.close()

        if not generos:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron géneros en las series')
            return

        opciones = [f"{g} ({len(generos[g])})" for g in sorted(generos.keys())]
        seleccion = xbmcgui.Dialog().select('Selecciona género', opciones)
        if seleccion < 0:
            return

        genero_sel = sorted(generos.keys())[seleccion]
        series_sel = generos[genero_sel]

        for s in series_sel:
            nombre = s['name']
            if s['year']:
                nombre += f" ({s['year']})"
            if s['rating']:
                try:
                    r = float(s['rating'])
                    estrellas = '⭐' * min(5, int(r))
                    if estrellas:
                        nombre += f" {estrellas}"
                except:
                    pass

            plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={s['serie_id']}") + "&mode=20&name=" + urllib.parse.quote_plus(nombre) + "&iconimage=" + urllib.parse.quote_plus(s['logo']) + "&serie_id=" + str(s['serie_id'])
            li = xbmcgui.ListItem(nombre)
            li.setArt({'icon': s['logo'], 'thumb': s['logo']})
            li.setProperty('fanart_image', fanart)

            cm = []
            cm.append(('Información', f'RunPlugin({sys.argv[0]}?url={s["serie_id"]}&mode=202&name={urllib.parse.quote_plus(s["name"])})'))
            li.addContextMenuItems(cm)

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def buscar_series_general():
    kb = xbmc.Keyboard('', 'Buscador general de series\nBusca en título y sinopsis\nEscribe el texto a buscar', True)
    kb.setHeading('Buscador general de series')
    kb.setHiddenInput(False)
    kb.doModal()
    if not kb.isConfirmed():
        return
    texto = kb.getText().strip()
    if not texto or len(texto) < 2:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Ingresa al menos 2 caracteres')
        return

    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, f"Buscando series: {texto}...")
    progress.update(0)

    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=30)
        data = response.read().decode('utf-8')
        response.close()

        if not data:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron series')
            return

        series_list = json.loads(data)
        resultados = []

        for idx, serie in enumerate(series_list):
            if idx % 20 == 0:
                progress.update(int((idx * 100) / len(series_list)), f"Analizando {idx+1}/{len(series_list)}")
                if progress.iscanceled():
                    progress.close()
                    return

            nombre = limpiar_texto(serie.get('name', '')).lower()
            if texto.lower() in nombre:
                resultados.append(serie)
                continue

            try:
                serie_id = serie.get('series_id', '')
                url_info = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
                req2 = urllib.request.Request(url_info)
                req2.add_header('User-Agent', 'Mozilla/5.0')
                resp2 = urllib.request.urlopen(req2, timeout=10)
                data2 = resp2.read().decode('utf-8')
                resp2.close()
                if data2:
                    info = json.loads(data2).get('info', {})
                    plot = info.get('plot', '').lower()
                    if texto.lower() in plot:
                        resultados.append(serie)
            except:
                continue

        progress.close()

        if not resultados:
            xbmcgui.Dialog().ok(ADDON_NAME, f'No se encontraron series para:\n\n"{texto}"')
            return

        xbmcgui.Dialog().notification(ADDON_NAME, f'Encontradas {len(resultados)} series', icon, 3000)

        for serie in resultados:
            nombre = limpiar_texto(serie.get('name', 'Sin nombre'))
            serie_id = serie.get('series_id', '')
            logo = serie.get('cover', '') or serie.get('cover_big', '') or icon
            year = serie.get('releaseDate', '')[:4]
            rating = serie.get('rating', '')

            nombre_mostrar = nombre
            if year:
                nombre_mostrar += f" ({year})"
            if rating:
                try:
                    r = float(rating)
                    estrellas = '⭐' * min(5, int(r))
                    if estrellas:
                        nombre_mostrar += f" {estrellas}"
                except:
                    pass

            plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}") + "&mode=20&name=" + urllib.parse.quote_plus(nombre_mostrar) + "&iconimage=" + urllib.parse.quote_plus(logo) + "&serie_id=" + str(serie_id)
            li = xbmcgui.ListItem(nombre_mostrar)
            li.setArt({'icon': logo, 'thumb': logo})
            li.setProperty('fanart_image', fanart)

            cm = []
            cm.append(('Información', f'RunPlugin({sys.argv[0]}?url={serie_id}&mode=202&name={urllib.parse.quote_plus(nombre)})'))
            li.addContextMenuItems(cm)

            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

# ==================== SERIES ====================
def series():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Cargando canales de series...")
    progress.update(0)

    try:
        progress.update(10, "Obteniendo lista de series...")
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=60)
        data = response.read().decode('utf-8')
        response.close()

        if data:
            if not os.path.exists(ADDONDATA):
                os.makedirs(ADDONDATA)
            with open(os.path.join(ADDONDATA, 'series_list.json'), 'w', encoding='utf-8') as f:
                f.write(data)

        progress.update(30, "Obteniendo categorías de series...")
        url_cats = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_categories"
        req2 = urllib.request.Request(url_cats)
        req2.add_header('User-Agent', 'Mozilla/5.0')
        response2 = urllib.request.urlopen(req2, timeout=15)
        data_cats = response2.read().decode('utf-8')
        response2.close()

        if data_cats:
            with open(os.path.join(ADDONDATA, 'series_categories.json'), 'w', encoding='utf-8') as f:
                f.write(data_cats)

        if data_cats:
            categories = json.loads(data_cats)
            for cat in categories:
                nombre_canal = limpiar_texto(cat.get('category_name', 'Sin nombre'))
                cat_id = cat.get('category_id', '')
                url_cat = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series&category_id={cat_id}"
                add_item(nombre_canal, url_cat, 19, icon, '', nombre_canal)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        progress.close()

    except Exception as e:
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def series_list(url, canal_nombre=""):
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read().decode('utf-8')
        response.close()

        if data:
            dns, user, pw = get_creds()
            canal_id = None
            if canal_nombre:
                try:
                    with open(os.path.join(ADDONDATA, 'series_categories.json'), 'r', encoding='utf-8') as f:
                        cats = json.load(f)
                        for cat in cats:
                            if cat.get('category_name') == canal_nombre:
                                canal_id = cat.get('category_id')
                                break
                except:
                    pass

            for serie in json.loads(data):
                nombre_serie = limpiar_texto(serie.get('name', 'Sin nombre'))
                serie_id = serie.get('series_id', '')
                logo = serie.get('cover', '') or serie.get('cover_big', '') or icon

                nombre_con_canal = f"[{canal_nombre}] {nombre_serie}" if canal_nombre else nombre_serie

                plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}") + "&mode=20&name=" + urllib.parse.quote_plus(nombre_con_canal) + "&iconimage=" + urllib.parse.quote_plus(logo) + "&canal=" + urllib.parse.quote_plus(canal_nombre) + "&serie_id=" + str(serie_id)
                li = xbmcgui.ListItem(nombre_serie)
                li.setArt({'icon': logo, 'thumb': logo})
                li.setProperty('fanart_image', fanart)

                cm = []
                cm.append(('Información', f'RunPlugin({sys.argv[0]}?url={serie_id}&mode=202&name={urllib.parse.quote_plus(nombre_serie)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
                if canal_nombre and canal_id:
                    cm.append(('Generar M3U completo de este canal', f'RunPlugin({sys.argv[0]}?mode=122&url={urllib.parse.quote_plus(canal_nombre)}&canal_id={canal_id})'))
                li.addContextMenuItems(cm)

                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:80]}')

def series_seasons(url, nombre_serie, iconimage, canal_nombre="", serie_id=""):
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read().decode('utf-8')
        response.close()

        if data:
            dns, user, pw = get_creds()
            info_serie = json.loads(data)
            episodios = info_serie.get('episodes', {})

            temporadas = sorted([int(t) for t in episodios.keys() if t.isdigit()])

            for temp in temporadas:
                nombre_temp = f"Temporada {temp}"

                plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=21&name=" + urllib.parse.quote_plus(nombre_temp) + "&iconimage=" + urllib.parse.quote_plus(iconimage) + "&canal=" + urllib.parse.quote_plus(canal_nombre) + "&serie_id=" + str(serie_id) + "&temporada=" + str(temp)
                li = xbmcgui.ListItem(nombre_temp)
                li.setArt({'icon': iconimage, 'thumb': iconimage})
                li.setProperty('fanart_image', fanart)

                cm = []
                cm.append(('📥 Descargar temporada', f'RunPlugin({sys.argv[0]}?url={serie_id}&mode=203&name={urllib.parse.quote_plus(nombre_serie)}&canal={urllib.parse.quote_plus(canal_nombre)}&temporada={temp})'))
                li.addContextMenuItems(cm)

                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=True)

            if temporadas:
                plugin_url_all = sys.argv[0] + "?url=" + urllib.parse.quote_plus(url) + "&mode=204&name=" + urllib.parse.quote_plus(nombre_serie) + "&iconimage=" + urllib.parse.quote_plus(iconimage) + "&canal=" + urllib.parse.quote_plus(canal_nombre) + "&serie_id=" + str(serie_id)
                li_all = xbmcgui.ListItem("[B][COLOR lime]📥 DESCARGAR SERIE COMPLETA[/COLOR][/B]")
                li_all.setArt({'icon': iconimage, 'thumb': iconimage})
                li_all.setProperty('fanart_image', fanart)
                xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url_all, listitem=li_all, isFolder=False)

        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:80]}')

def series_episodes(url, nombre_serie, iconimage, canal_nombre="", serie_id="", temporada=""):
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=15)
        data = response.read().decode('utf-8')
        response.close()
        
        if data:
            dns, user, pw = get_creds()
            info_serie = json.loads(data)
            episodios = info_serie.get('episodes', {})
            
            if temporada and temporada in episodios:
                capitulos = episodios[temporada]
                
                for ep in capitulos:
                    titulo = limpiar_texto(ep.get('title', f'Episodio {ep.get("episode_num", "")}'))
                    num_ep = ep.get('episode_num', '')
                    if num_ep:
                        titulo = f"{num_ep} - {titulo}"
                    
                    ep_id = ep.get('id', '')
                    contenedor = ep.get('container_extension', 'mp4')
                    play_url = f"{dns}/series/{user}/{pw}/{ep_id}.{contenedor}"
                    
                    nombre_con_canal = f"[{canal_nombre}] {nombre_serie} - {titulo}" if canal_nombre else f"{nombre_serie} - {titulo}"
                    
                    plugin_url = sys.argv[0] + "?url=" + urllib.parse.quote_plus(play_url) + "&mode=4&name=" + urllib.parse.quote_plus(nombre_con_canal) + "&iconimage=" + urllib.parse.quote_plus(iconimage) + "&canal=" + urllib.parse.quote_plus(canal_nombre)
                    li = xbmcgui.ListItem(titulo)
                    li.setArt({'icon': iconimage, 'thumb': iconimage})
                    li.setProperty('fanart_image', fanart)
                    li.setProperty('IsPlayable', 'true')
                    
                    cm = []
                    if es_favorito(play_url):
                        cm.append(('❌ Eliminar de Favoritos', f'RunPlugin({sys.argv[0]}?mode=32&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(nombre_con_canal)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
                    else:
                        cm.append(('Añadir a Favoritos menu', f'RunPlugin({sys.argv[0]}?mode=33&url={urllib.parse.quote_plus(play_url)}&name={urllib.parse.quote_plus(nombre_con_canal)}&iconimage={urllib.parse.quote_plus(iconimage)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
                    cm.append(('Descargar', f'RunPlugin({sys.argv[0]}?url={urllib.parse.quote_plus(play_url)}&mode=200&name={urllib.parse.quote_plus(nombre_con_canal)}&canal={urllib.parse.quote_plus(canal_nombre)})'))
                    li.addContextMenuItems(cm)
                    
                    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=plugin_url, listitem=li, isFolder=False)
        
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:80]}')

def descargar_temporada(serie_id, nombre_serie, canal_nombre, temporada):
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    
    download_path = xbmcgui.Dialog().browse(3, 'Selecciona carpeta para guardar la temporada', 'files')
    if not download_path:
        return
    
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=30)
        data = response.read().decode('utf-8')
        response.close()
        
        if not data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo obtener información de la serie')
            return
        
        info_serie = json.loads(data)
        episodios = info_serie.get('episodes', {})
        
        if temporada not in episodios:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron episodios para esta temporada')
            return
        
        capitulos = episodios[temporada]
        total = len(capitulos)
        
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, f"Descargando temporada {temporada} de {nombre_serie}")
        progress.update(0)
        
        carpeta_temporada = os.path.join(download_path, f"{limpiar_texto(nombre_serie)} - Temporada {temporada}")
        if not os.path.exists(carpeta_temporada):
            os.makedirs(carpeta_temporada)
        
        for idx, ep in enumerate(capitulos):
            percent = int((idx * 100) / total)
            progress.update(percent, f"Descargando episodio {idx+1}/{total}")
            
            titulo = limpiar_texto(ep.get('title', f'Episodio {ep.get("episode_num", "")}'))
            num_ep = ep.get('episode_num', '')
            if num_ep:
                titulo = f"{num_ep} - {titulo}"
            
            ep_id = ep.get('id', '')
            contenedor = ep.get('container_extension', 'mp4')
            play_url = f"{dns}/series/{user}/{pw}/{ep_id}.{contenedor}"
            
            nombre_archivo = f"{titulo}.{contenedor}"
            nombre_limpio = re.sub(r'[<>:"/\\|?*]', '_', nombre_archivo)
            archivo = os.path.join(carpeta_temporada, nombre_limpio)
            
            if os.path.exists(archivo):
                continue
            
            try:
                req2 = urllib.request.Request(play_url)
                req2.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
                req2.add_header('Accept', '*/*')
                req2.add_header('Connection', 'keep-alive')
                resp = urllib.request.urlopen(req2, timeout=30)
                
                with open(archivo, 'wb') as f:
                    while True:
                        chunk = resp.read(8192)
                        if not chunk:
                            break
                        f.write(chunk)
            except:
                continue
            
            if progress.iscanceled():
                break
        
        progress.close()
        xbmcgui.Dialog().ok(ADDON_NAME, f'Descarga completada\n\n{carpeta_temporada}')
        
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def descargar_serie_completa(serie_id, nombre_serie, canal_nombre):
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    
    download_path = xbmcgui.Dialog().browse(3, 'Selecciona carpeta para guardar la serie completa', 'files')
    if not download_path:
        return
    
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=30)
        data = response.read().decode('utf-8')
        response.close()
        
        if not data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo obtener información de la serie')
            return
        
        info_serie = json.loads(data)
        episodios = info_serie.get('episodes', {})
        
        temporadas = sorted([int(t) for t in episodios.keys() if t.isdigit()])
        
        if not temporadas:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron temporadas')
            return
        
        total_episodios = 0
        for temp in temporadas:
            total_episodios += len(episodios[str(temp)])
        
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, f"Descargando serie completa: {nombre_serie}")
        progress.update(0)
        
        carpeta_serie = os.path.join(download_path, limpiar_texto(nombre_serie))
        if not os.path.exists(carpeta_serie):
            os.makedirs(carpeta_serie)
        
        episodios_descargados = 0
        errores = 0
        
        for temp in temporadas:
            capitulos = episodios[str(temp)]
            
            carpeta_temp = os.path.join(carpeta_serie, f"Temporada {temp}")
            if not os.path.exists(carpeta_temp):
                os.makedirs(carpeta_temp)
            
            for ep in capitulos:
                percent = int((episodios_descargados * 100) / total_episodios) if total_episodios > 0 else 0
                progress.update(percent, f"Descargando episodio {episodios_descargados+1}/{total_episodios}\nTemporada {temp}")
                
                titulo = limpiar_texto(ep.get('title', f'Episodio {ep.get("episode_num", "")}'))
                num_ep = ep.get('episode_num', '')
                if num_ep:
                    titulo = f"{num_ep} - {titulo}"
                
                ep_id = ep.get('id', '')
                contenedor = ep.get('container_extension', 'mp4')
                play_url = f"{dns}/series/{user}/{pw}/{ep_id}.{contenedor}"
                
                nombre_archivo = f"{titulo}.{contenedor}"
                nombre_limpio = re.sub(r'[<>:"/\\|?*]', '_', nombre_archivo)
                archivo = os.path.join(carpeta_temp, nombre_limpio)
                
                if os.path.exists(archivo):
                    episodios_descargados += 1
                    continue
                
                try:
                    req2 = urllib.request.Request(play_url)
                    req2.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
                    req2.add_header('Accept', '*/*')
                    req2.add_header('Connection', 'keep-alive')
                    resp = urllib.request.urlopen(req2, timeout=30)
                    
                    with open(archivo, 'wb') as f:
                        while True:
                            chunk = resp.read(8192)
                            if not chunk:
                                break
                            f.write(chunk)
                    
                    episodios_descargados += 1
                    
                except Exception as e:
                    xbmc.log(f'IPTVXC: Error descargando episodio: {e}', xbmc.LOGERROR)
                    errores += 1
                    episodios_descargados += 1
                    continue
                
                if progress.iscanceled():
                    progress.close()
                    xbmcgui.Dialog().ok(ADDON_NAME, f'Descarga cancelada\n\nDescargados: {episodios_descargados - errores} episodios')
                    return
        
        progress.close()
        
        mensaje = f'DESCARGA COMPLETADA\n\n'
        mensaje += f'Serie: {nombre_serie}\n'
        mensaje += f'Episodios descargados: {episodios_descargados - errores}\n'
        if errores > 0:
            mensaje += f'Errores: {errores}\n'
        mensaje += f'\nUbicación:\n{carpeta_serie}'
        
        xbmcgui.Dialog().ok(ADDON_NAME, mensaje)
        
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def info_serie(serie_id, nombre_serie, canal=''):
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        return
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_series_info&series_id={serie_id}"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=20)
        data = response.read().decode('utf-8')
        response.close()
        if data:
            detalle = json.loads(data)
            info = detalle.get('info', {})
            texto = f"[B]{limpiar_texto(nombre_serie)}[/B]\n\n"
            if canal:
                texto += f"Canal: {canal}\n"
            texto += f"Año: {info.get('releasedate', 'N/A')[:4]}\n"
            texto += f"Rating: {info.get('rating', 'N/A')}\n"
            texto += f"Género: {info.get('genre', 'N/A')}\n"
            texto += f"Director: {info.get('director', 'N/A')}\n"
            texto += f"Actores: {info.get('cast', 'N/A')[:300]}\n"
            texto += f"Duración episodios: {info.get('episode_run_time', 'N/A')} min\n\n"
            texto += f"Sinopsis:\n{info.get('plot', 'No disponible')[:500]}"
            
            logo = info.get('cover_big', '') or info.get('cover', '') or icon
            opciones = ['Ver temporadas', 'Grabar serie completa', '❌ Cerrar']
            seleccion = xbmcgui.Dialog().select(f"Información: {nombre_serie}", opciones)
            if seleccion == 0:
                # Redirigir a la lista de temporadas
                xbmc.executebuiltin(f'Container.Update({sys.argv[0]}?url={urllib.parse.quote_plus(url)}&mode=20&name={urllib.parse.quote_plus(nombre_serie)}&iconimage={urllib.parse.quote_plus(logo)}&canal={urllib.parse.quote_plus(canal)}&serie_id={serie_id})')
            elif seleccion == 1:
                descargar_serie_completa(serie_id, nombre_serie, canal)
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo obtener información')
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')


# ==================== REPRODUCCIÓN CON GRABACIÓN DURANTE REPRODUCCIÓN ====================

class RecordingPlayer(xbmc.Player):
    """Reproductor personalizado que permite grabar durante la reproducción"""
    
    def __init__(self):
        super().__init__()
        self.grabando = False
        self.archivo_grabacion = None
        self.response = None
        self.hilo_grabacion = None
        self.url_actual = ""
        self.nombre_actual = ""
        self.icon_actual = ""
        self.canal_actual = ""
        self.progress_dialog = None
        self.total_descargado = 0
        self.inicio_grabacion = 0
        self.duracion_maxima = 0
        
    def onPlayBackStarted(self):
        """Se llama cuando comienza la reproducción"""
        xbmc.log(f'IPTVXC: Reproducción iniciada', xbmc.LOGINFO)
        # Mostrar notificación de que se puede grabar
        xbmcgui.Dialog().notification(ADDON_NAME, '💾 Presiona C y selecciona "Grabar" para guardar', icon, 5000)
        
    def onPlayBackStopped(self):
        """Se llama cuando se detiene la reproducción"""
        xbmc.log(f'IPTVXC: Reproducción detenida', xbmc.LOGINFO)
        self.detener_grabacion()
        
    def onPlayBackEnded(self):
        """Se llama cuando termina la reproducción"""
        xbmc.log(f'IPTVXC: Reproducción finalizada', xbmc.LOGINFO)
        self.detener_grabacion()
        
    def onPlayBackError(self):
        """Se llama cuando hay error de reproducción"""
        xbmc.log(f'IPTVXC: Error en reproducción', xbmc.LOGERROR)
        self.detener_grabacion()
        
    def iniciar_grabacion(self, url, nombre, iconimage, canal, duracion_maxima=0):
        """Inicia la grabación del stream actual en segundo plano"""
        if self.grabando:
            xbmcgui.Dialog().ok(ADDON_NAME, '⚠️ Ya hay una grabación en curso')
            return False
            
        try:
            # Seleccionar carpeta de destino
            download_path = xbmcgui.Dialog().browse(3, '📁 Selecciona carpeta para guardar la grabación', 'files')
            if not download_path:
                return False
            
            # Crear nombre de archivo con timestamp
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            nombre_limpio = re.sub(r'[<>:"/\\|?*]', '_', nombre)
            
            if canal:
                nombre_archivo = f"{canal} - {nombre_limpio} - {timestamp}.ts"
            else:
                nombre_archivo = f"{nombre_limpio} - {timestamp}.ts"
            
            self.archivo_grabacion = os.path.join(download_path, nombre_archivo)
            
            # Verificar si ya existe
            if os.path.exists(self.archivo_grabacion):
                if not xbmcgui.Dialog().yesno(ADDON_NAME, f'⚠️ El archivo ya existe:\n{nombre_archivo}\n\n¿Sobrescribir?'):
                    return False
            
            # Conectar al stream
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            req.add_header('Accept', '*/*')
            req.add_header('Connection', 'keep-alive')
            
            self.response = urllib.request.urlopen(req, timeout=30)
            self.url_actual = url
            self.nombre_actual = nombre
            self.icon_actual = iconimage
            self.canal_actual = canal
            self.grabando = True
            self.inicio_grabacion = time.time()
            self.duracion_maxima = duracion_maxima
            self.total_descargado = 0
            
            # Crear diálogo de progreso
            self.progress_dialog = xbmcgui.DialogProgress()
            self.progress_dialog.create(ADDON_NAME, f"⏺️ GRABANDO: {nombre_limpio[:50]}")
            self.progress_dialog.update(0, "Iniciando grabación...")
            
            # Iniciar hilo de grabación en segundo plano
            import threading
            self.hilo_grabacion = threading.Thread(target=self._grabar_stream)
            self.hilo_grabacion.daemon = True
            self.hilo_grabacion.start()
            
            # Mostrar notificación
            if duracion_maxima > 0:
                minutos = duracion_maxima // 60
                xbmcgui.Dialog().notification(ADDON_NAME, f'⏺️ Grabando durante {minutos} minutos', icon, 3000)
            else:
                xbmcgui.Dialog().notification(ADDON_NAME, '⏺️ Grabando sin límite de tiempo', icon, 3000)
            
            return True
            
        except Exception as e:
            xbmc.log(f'IPTVXC: Error iniciando grabación: {e}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok(ADDON_NAME, f'❌ Error al iniciar grabación:\n{str(e)[:100]}')
            return False
    
# Variable global para el reproductor
            #_reproductor_actual = None

    def _grabar_stream(self):
        """Hilo que realiza la grabación en segundo plano"""
        try:
            with open(self.archivo_grabacion, 'wb') as f:
                errores_consecutivos = 0
                ultima_actualizacion = 0
                
                while self.grabando and self.isPlaying():
                    try:
                        chunk = self.response.read(8192)
                        if not chunk:
                            xbmc.log('IPTVXC: Fin del stream, deteniendo grabación', xbmc.LOGINFO)
                            break
                        
                        f.write(chunk)
                        self.total_descargado += len(chunk)
                        errores_consecutivos = 0
                        
                        # Actualizar diálogo de progreso cada 0.5 segundos
                        ahora = time.time()
                        if ahora - ultima_actualizacion > 0.5:
                            ultima_actualizacion = ahora
                            mb = self.total_descargado // (1024 * 1024)
                            
                            if self.progress_dialog:
                                if self.duracion_maxima > 0:
                                    tiempo_restante = int(self.duracion_maxima - (ahora - self.inicio_grabacion))
                                    minutos_rest = tiempo_restante // 60
                                    seg_rest = tiempo_restante % 60
                                    self.progress_dialog.update(0, f"📀 Grabado: {mb} MB\n⏱️ Restante: {minutos_rest}m {seg_rest}s\nPresiona Cancelar para detener")
                                else:
                                    self.progress_dialog.update(0, f"📀 Grabado: {mb} MB\nPresiona Cancelar para detener")
                        
                        # Verificar límite de tiempo
                        if self.duracion_maxima > 0 and (time.time() - self.inicio_grabacion) > self.duracion_maxima:
                            xbmc.log(f'IPTVXC: Límite de tiempo alcanzado ({self.duracion_maxima}s)', xbmc.LOGINFO)
                            break
                            
                        # Verificar si el usuario canceló
                        if self.progress_dialog and self.progress_dialog.iscanceled():
                            xbmc.log('IPTVXC: Usuario canceló grabación', xbmc.LOGINFO)
                            break
                            
                    except Exception as e:
                        errores_consecutivos += 1
                        if errores_consecutivos >= 5:
                            xbmc.log(f'IPTVXC: Demasiados errores en grabación: {e}', xbmc.LOGERROR)
                            break
                        xbmc.sleep(1000)
                        
        except Exception as e:
            xbmc.log(f'IPTVXC: Error en hilo de grabación: {e}', xbmc.LOGERROR)
        finally:
            self._finalizar_grabacion()
    
    def _finalizar_grabacion(self):
        """Finaliza la grabación y muestra resultados"""
        self.grabando = False
        
        if self.progress_dialog:
            self.progress_dialog.close()
            self.progress_dialog = None
            
        if self.response:
            try:
                self.response.close()
            except:
                pass
            self.response = None
        
        # Verificar resultado
        if self.archivo_grabacion and os.path.exists(self.archivo_grabacion):
            tamaño = os.path.getsize(self.archivo_grabacion)
            if tamaño > 10240:  # mínimo 10KB
                mb = tamaño // (1024 * 1024)
                xbmcgui.Dialog().notification(ADDON_NAME, f'✅ Grabación completada: {mb} MB', icon, 5000)
                xbmc.log(f'IPTVXC: Grabación guardada: {self.archivo_grabacion} ({mb} MB)', xbmc.LOGINFO)
            else:
                os.remove(self.archivo_grabacion)
                xbmcgui.Dialog().ok(ADDON_NAME, '❌ Grabación fallida: archivo demasiado pequeño')
        else:
            if self.progress_dialog:
                xbmcgui.Dialog().ok(ADDON_NAME, '❌ Grabación cancelada')
    
    def detener_grabacion(self):
        """Detiene la grabación actual manualmente"""
        if self.grabando:
            self.grabando = False
            xbmcgui.Dialog().notification(ADDON_NAME, '⏹️ Deteniendo grabación...', icon, 2000)


def play_video(url, name, iconimage, canal=''):
    """Reproduce video con capacidad de grabación mediante menú contextual"""
    global _reproductor_actual
    
    try:
        xbmc.log(f'IPTVXC: Reproduciendo: {url}', xbmc.LOGINFO)
        agregar_historial(url, name, iconimage, canal)
        
        # Crear ListItem
        li = xbmcgui.ListItem(limpiar_texto(name))
        li.setArt({'icon': iconimage, 'thumb': iconimage, 'poster': iconimage})
        li.setPath(url)
        li.setProperty('IsPlayable', 'true')
        li.setProperty('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        li.setProperty('Accept', '*/*')
        li.setProperty('Connection', 'keep-alive')
        li.setProperty('cache', 'true')
        li.setProperty('cache-mem-buffers', '31457280')
        li.setProperty('cache-size', '30M')
        li.setProperty('readbuffer', 'true')
        li.setProperty('readbuffer-size', '30M')
        li.setProperty('conn-timeout', '30')
        
        if '.m3u8' in url or '/live/' in url:
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        # Crear reproductor personalizado
        _reproductor_actual = RecordingPlayer()
        
        # Añadir menú contextual para grabar
        cm = []
        cm.append(('Grabar este contenido', f'RunPlugin({sys.argv[0]}?mode=210&url={urllib.parse.quote_plus(url)}&name={urllib.parse.quote_plus(name)}&iconimage={urllib.parse.quote_plus(iconimage)}&canal={urllib.parse.quote_plus(canal)})'))
        li.addContextMenuItems(cm)
        
        # Iniciar reproducción
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        
    except Exception as e:
        xbmc.log(f'IPTVXC: Error en play_video: {e}', xbmc.LOGERROR)
        opciones = ['Reintentar', 'Cancelar']
        if xbmcgui.Dialog().select('Error de reproducción', opciones) == 0:
            play_video(url, name, iconimage, canal)

# ==================== EXTRAS ====================
def extras():
    add_item('Limpiar Historial', 'clear_history', 10, icon)
    add_item('Limpiar Caché', 'clear_cache', 95, icon)
    add_item('Depurar datos básicos', 'debug_basic', 96, icon)
    add_item('Depurar detalles completos (get_vod_info)', 'debug_details', 97, icon)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def speedtest():
    try:
        from resources.modules import speedtest
        speedtest.speedtest()
    except:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Función de prueba de velocidad en desarrollo')

def clear_cache():
    cache_path = os.path.join(ADDONDATA, 'cache')
    if os.path.exists(cache_path):
        import shutil
        shutil.rmtree(cache_path)
        xbmcgui.Dialog().ok(ADDON_NAME, 'Caché limpiada')
    else:
        xbmcgui.Dialog().ok(ADDON_NAME, 'No hay caché')

# ==================== DEPURACIÓN ====================
def debug_movie_basic():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_streams"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=30)
        data = response.read().decode('utf-8')
        response.close()
        movies_data = json.loads(data)
        if not movies_data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron películas')
            return
        info_text = "=== DATOS BÁSICOS DE LAS PRIMERAS 5 PELÍCULAS ===\n\n"
        for idx, movie in enumerate(movies_data[:5]):
            info_text += f"PELÍCULA {idx+1}:\n"
            info_text += f"   Nombre: {limpiar_texto(movie.get('name', 'N/A'))}\n"
            info_text += f"   Stream ID: {movie.get('stream_id', 'N/A')}\n"
            info_text += f"   Categoría ID: {movie.get('category_id', 'N/A')}\n"
            info_text += f"   Categorías: {movie.get('category_ids', [])}\n"
            info_text += f"   Stream Icon: {movie.get('stream_icon', 'N/A')[:80]}\n"
            info_text += f"   Rating: {movie.get('rating', 'N/A')}\n"
            info_text += f"   Year: {movie.get('year', 'N/A')}\n"
            info_text += f"   Container: {movie.get('container_extension', 'N/A')}\n\n"
        xbmcgui.Dialog().textviewer("Depuración - Datos básicos", info_text)
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

def debug_movie_details():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura primero las credenciales')
        return
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_streams"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=30)
        data = response.read().decode('utf-8')
        response.close()
        movies_data = json.loads(data)
        if not movies_data:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se encontraron películas')
            return
        opciones = []
        for movie in movies_data[:100]:
            nombre = limpiar_texto(movie.get('name', 'Sin nombre'))
            opciones.append(nombre)
        seleccion = xbmcgui.Dialog().select('Selecciona una película para ver sus detalles', opciones)
        if seleccion < 0:
            return
        pelicula = movies_data[seleccion]
        stream_id = pelicula.get('stream_id', '')
        nombre = pelicula.get('name', 'Sin nombre')
        details_url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_info&vod_id={stream_id}"
        req2 = urllib.request.Request(details_url)
        req2.add_header('User-Agent', 'Mozilla/5.0')
        response2 = urllib.request.urlopen(req2, timeout=30)
        details_data = response2.read().decode('utf-8')
        response2.close()
        info_text = f"  PELÍCULA \n"
        info_text += f"Nombre: {limpiar_texto(nombre)}\n"
        info_text += f"Stream ID: {stream_id}\n\n"
        info_text += f"=== URL DE DETALLE ===\n{details_url}\n\n"
        info_text += f"=== DATOS COMPLETOS DEVUELTOS ===\n\n"
        try:
            details = json.loads(details_data)
            info_text += "CLAVES PRINCIPALES:\n"
            for key in details.keys():
                info_text += f"   • {key}\n"
            if 'info' in details and isinstance(details['info'], dict):
                info_text += "\nOBJETO 'info':\n"
                for key in details['info'].keys():
                    val = str(details['info'][key])[:200]
                    info_text += f"   • {key}: {val}\n"
            if 'movie_data' in details and isinstance(details['movie_data'], dict):
                info_text += "\nOBJETO 'movie_data':\n"
                for key in details['movie_data'].keys():
                    val = str(details['movie_data'][key])[:200]
                    info_text += f"   • {key}: {val}\n"
            info_text += "\nCAMPOS ESPECÍFICOS BUSCADOS:\n"
            campos_buscar = ['plot', 'description', 'synopsis', 'director', 'cast', 'actors', 'genre', 'duration', 'runtime', 'year', 'releaseDate', 'rating', 'imdb', 'tmdb', 'cover_big', 'backdrop_path', 'stream_icon']
            for campo in campos_buscar:
                encontrado = False
                if campo in details:
                    val = str(details[campo])[:150]
                    info_text += f"   ✓ {campo}: {val}\n"
                    encontrado = True
                elif 'info' in details and campo in details['info']:
                    val = str(details['info'][campo])[:150]
                    info_text += f"   ✓ info.{campo}: {val}\n"
                    encontrado = True
                elif 'movie_data' in details and campo in details['movie_data']:
                    val = str(details['movie_data'][campo])[:150]
                    info_text += f"   ✓ movie_data.{campo}: {val}\n"
                    encontrado = True
                if not encontrado:
                    info_text += f"   ✗ {campo}: No encontrado\n"
            info_text += f"\n\nJSON COMPLETO (primeros 800 caracteres):\n"
            info_text += json.dumps(details, indent=2, ensure_ascii=False)[:800]
        except json.JSONDecodeError as e:
            info_text += f"Error decodificando JSON: {e}\n{details_data[:500]}"
        except Exception as e:
            info_text += f"Error procesando datos: {e}\n"
        xbmcgui.Dialog().textviewer("Depuración - Detalles completos", info_text)
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')

# ==================== INFO ====================
def info_pelicula(stream_id, name, canal=''):
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        return
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}&action=get_vod_info&vod_id={stream_id}"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=20)
        data = response.read().decode('utf-8')
        response.close()
        if data:
            detalle = json.loads(data)
            info = detalle.get('info', {})
            movie_data = detalle.get('movie_data', {})
            ext = movie_data.get('container_extension', 'mp4')
            play_url = f"{dns}/movie/{user}/{pw}/{stream_id}.{ext}"
            logo = info.get('cover_big', '') or info.get('movie_image', '') or icon
            
            texto = f"[B]{name}[/B]\n\n"
            if canal:
                texto += f"Canal: {canal}\n"
            texto += f"Año: {info.get('releasedate', 'N/A')[:4]}\n"
            texto += f"Rating: {info.get('rating', 'N/A')}\n"
            texto += f"Género: {info.get('genre', 'N/A')}\n"
            texto += f"Director: {info.get('director', 'N/A')}\n"
            texto += f"Actores: {info.get('cast', 'N/A')[:300]}\n"
            texto += f"Duración: {info.get('duration', 'N/A')}\n\n"
            texto += f"Sinopsis:\n{info.get('plot', 'No disponible')[:500]}"
            
            opciones = ['Reproducir', 'Grabar película', '❌ Cerrar']
            seleccion = xbmcgui.Dialog().select(f"Información: {name}", opciones)
            if seleccion == 0:
                play_video(play_url, name, logo, canal)
            elif seleccion == 1:
                descargar_pelicula(play_url, name, canal)
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, 'No se pudo obtener información')
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:100]}')



def descargar_pelicula(url, name, canal=''):
    try:
        download_path = xbmcgui.Dialog().browse(3, 'Selecciona carpeta para guardar', 'files')
        if not download_path:
            return
        if canal:
            nombre_archivo = f"{canal} - {name}"
        else:
            nombre_archivo = name
        nombre_limpio = re.sub(r'[<>:"/\\|?*]', '_', nombre_archivo)
        archivo = os.path.join(download_path, f"{nombre_limpio}.mp4")
        
        if os.path.exists(archivo):
            if not xbmcgui.Dialog().yesno(ADDON_NAME, f'El archivo ya existe:\n{nombre_limpio}.mp4\n\n¿Sobrescribir?', yeslabel='Sobrescribir', nolabel='Cancelar'):
                return
        
        progress = xbmcgui.DialogProgress()
        progress.create(ADDON_NAME, f"Conectando...")
        progress.update(0)
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        req.add_header('Accept', '*/*')
        req.add_header('Connection', 'keep-alive')
        try:
            response = urllib.request.urlopen(req, timeout=30)
        except Exception as e:
            progress.close()
            xbmcgui.Dialog().ok(ADDON_NAME, f'Error de conexión\n{str(e)[:100]}')
            return
        
        total = 0
        try:
            total = int(response.headers.get('Content-Length', 0))
        except:
            total = 0
        
        progress.update(0, f"Descargando: {nombre_limpio}")
        down = 0
        errores_consecutivos = 0
        
        with open(archivo, 'wb') as f:
            while True:
                try:
                    chunk = response.read(8192)
                    if not chunk:
                        break
                    f.write(chunk)
                    down += len(chunk)
                    if down % (1024 * 1024) < 8192:
                        mb_down = down // (1024 * 1024)
                        if total > 0:
                            mb_total = total // (1024 * 1024)
                            percent = int((down * 100) / total)
                            progress.update(percent, f"Descargando: {nombre_limpio}\n{mb_down} MB / {mb_total} MB")
                        else:
                            progress.update(0, f"Descargando: {nombre_limpio}\n{mb_down} MB")
                    errores_consecutivos = 0
                    
                    if progress.iscanceled():
                        f.close()
                        # ✅ NUEVO: preguntar si conservar lo descargado
                        if os.path.getsize(archivo) > 0:
                            if xbmcgui.Dialog().yesno(ADDON_NAME, 'Descarga cancelada. ¿Deseas conservar lo descargado hasta ahora?', yeslabel='Conservar', nolabel='Eliminar'):
                                mb = down // (1024 * 1024)
                                xbmcgui.Dialog().notification(ADDON_NAME, f'Archivo parcial guardado: {mb} MB', icon, 3000)
                            else:
                                os.remove(archivo)
                                xbmcgui.Dialog().ok(ADDON_NAME, 'Descarga cancelada y archivo eliminado')
                        else:
                            os.remove(archivo)
                            xbmcgui.Dialog().ok(ADDON_NAME, 'Descarga cancelada (archivo vacío)')
                        return
                        
                except Exception as e:
                    errores_consecutivos += 1
                    if errores_consecutivos >= 3:
                        progress.close()
                        xbmcgui.Dialog().ok(ADDON_NAME, f'Error de descarga\nDescargado: {down // (1024*1024)} MB')
                        f.close()
                        # También preguntar aquí
                        if os.path.getsize(archivo) > 0:
                            if xbmcgui.Dialog().yesno(ADDON_NAME, 'Error de conexión. ¿Conservar lo descargado?', yeslabel='Conservar', nolabel='Eliminar'):
                                pass
                            else:
                                os.remove(archivo)
                        else:
                            os.remove(archivo)
                        return
                    xbmc.sleep(1000)
                    continue
        
        progress.close()
        response.close()
        
        if os.path.exists(archivo) and os.path.getsize(archivo) > 10240:
            mb_final = os.path.getsize(archivo) // (1024 * 1024)
            xbmcgui.Dialog().ok(ADDON_NAME, f'✅ Descarga completada\n\n{nombre_limpio}.mp4\nTamaño: {mb_final} MB\n\n{download_path}')
        else:
            if os.path.exists(archivo):
                os.remove(archivo)
            xbmcgui.Dialog().ok(ADDON_NAME, 'Error: El archivo descargado está vacío o corrupto')
            
    except Exception as e:
        xbmc.log(f'IPTVXC: Error en descarga: {e}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error durante la descarga:\n{str(e)[:100]}')

# ==================== TEST CREDENCIALES ====================
def test_creds():
    dns, user, pw = get_creds()
    if not dns or not user or not pw:
        xbmcgui.Dialog().ok(ADDON_NAME, 'Configura DNS, Usuario y Contraseña')
        return
    try:
        url = f"{dns}/player_api.php?username={user}&password={pw}"
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        response = urllib.request.urlopen(req, timeout=10)
        data = response.read().decode('utf-8')
        response.close()
        if data and '"user_info"' in data:
            xbmcgui.Dialog().ok(ADDON_NAME, ' Credenciales correctas')
        else:
            xbmcgui.Dialog().ok(ADDON_NAME, ' Credenciales incorrectas')
    except Exception as e:
        xbmcgui.Dialog().ok(ADDON_NAME, f'Error: {str(e)[:80]}')

# ==================== MAIN ====================
if __name__ == '__main__':
    try:
        params = {}
        try:
            paramstring = sys.argv[2]
            if paramstring:
                for pair in paramstring.replace('?', '').split('&'):
                    if '=' in pair:
                        k, v = pair.split('=', 1)
                        params[k] = urllib.parse.unquote_plus(v)
        except:
            pass
        
        mode = params.get('mode', '')
        url = params.get('url', '')
        name = params.get('name', '')
        iconimage = params.get('iconimage', icon)
        description = params.get('description', '')
        canal = params.get('canal', '')
        
        if mode == '':
            dns, user, pw = get_creds()
            if not dns or not user or not pw:
                configurar_credenciales()
            main_menu()
        elif mode == '1':
            live_tv()
        elif mode == '2':
            live_streams(url)
        elif mode == '3':
            movies()
        elif mode == '4':
            play_video(url, name, iconimage, canal)
        elif mode == '5':
            buscador()
        elif mode == '6':
            account_info()
        elif mode == '7':
            tv_guide()
        elif mode == '8':
            config_menu()
        elif mode == '9':
            movie_list(url, canal)
        elif mode == '10':
            addonsettings(url, description)
        elif mode == '16':
            extras()
        elif mode == '18':
            series()
        elif mode == '19':
            series_list(url, canal)
        elif mode == '20':
            series_seasons(url, name, iconimage, canal, params.get('serie_id', ''))
        elif mode == '21':
            series_episodes(url, name, iconimage, canal, params.get('serie_id', ''), params.get('temporada', ''))
        elif mode == '30':
            mostrar_favoritos()
        elif mode == '31':
            mostrar_historial()
        elif mode == '32':
            eliminar_favorito(url)
            xbmc.executebuiltin('Container.Refresh')
        elif mode == '33':
            agregar_favorito(url, name, 4, iconimage, description, canal)
            xbmcgui.Dialog().notification(ADDON_NAME, '⭐ Añadido a favoritos', icon, 2000)
        elif mode == '34':
            eliminar_historial_item(url)
            xbmc.executebuiltin('Container.Refresh')
        elif mode == '95':
            clear_cache()
        elif mode == '96':
            debug_movie_basic()
        elif mode == '97':
            debug_movie_details()
        elif mode == '98':
            speedtest()
        elif mode == '99':
            server_settings()
        elif mode == '100':
            m3u_menu()
        elif mode == '102':
            # ver_archivos() - si existe
            pass
        elif mode == '110':
            generar_m3u_basico()
        elif mode == '111':
            generar_m3u_completo_canales()
        elif mode == '112':
            generar_m3u_completo_generos()
        elif mode == '113':
            m3u_peliculas()
        elif mode == '114':
            m3u_series()
        elif mode == '115':
            generar_m3u_series_basico()
        elif mode == '116':
            generar_m3u_series_canales()
        elif mode == '117':
            generar_m3u_series_generos()
        elif mode == '118':
            m3u_tv()
        elif mode == '119':
            generar_m3u_tv_basico()
        elif mode == '120':
            generar_m3u_tv_completo()
        elif mode == '121':
            generar_m3u_series_canales_completo()
        elif mode == '122':
            generar_m3u_series_canales_completo(canal_especifico_nombre=url, canal_especifico_id=params.get('canal_id', ''))
        elif mode == '200':
            descargar_pelicula(url, name, canal)  # o descargar_contenido()
        elif mode == '201':
            info_pelicula(url, name, canal)
        elif mode == '202':
            info_serie(url, name, canal)
        elif mode == '203':
            descargar_temporada(url, name, canal, params.get('temporada', ''))
        elif mode == '204':
            descargar_serie_completa(url, name, canal)
        elif mode == '210':
# Grabar durante la reproducción (desde menú contextual)
            if _reproductor_actual and _reproductor_actual.isPlaying():
                if not _reproductor_actual.grabando:
                    opciones = ['🎬 5 minutos', '🎬 10 minutos', '🎬 15 minutos', '🎬 30 minutos', '🎬 1 hora', '🎬 Sin límite', '❌ Cancelar']
                    seleccion = xbmcgui.Dialog().select('⏺️ Duración de grabación', opciones)
                    if seleccion == 6 or seleccion < 0:
                        pass
                    else:
                        duracion = 0
                        if seleccion == 0: duracion = 5 * 60
                        elif seleccion == 1: duracion = 10 * 60
                        elif seleccion == 2: duracion = 15 * 60
                        elif seleccion == 3: duracion = 30 * 60
                        elif seleccion == 4: duracion = 60 * 60
                        _reproductor_actual.iniciar_grabacion(url, name, iconimage, canal, duracion)
                else:
                    if xbmcgui.Dialog().yesno(ADDON_NAME, '⏺️ Hay una grabación en curso\n¿Deseas detenerla?'):
                        _reproductor_actual.detener_grabacion()
            else:
                xbmcgui.Dialog().ok(ADDON_NAME, '❌ No hay reproducción activa')
        else:
            main_menu()
    except Exception as e:
        import traceback
        xbmc.log(f'IPTVXC ERROR: {e}\n{traceback.format_exc()}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error', str(e)[:100])