#!/usr/bin/python
# -*- coding: utf-8 -*-
############################################################################
#							  /T /I										   #
#							   / |/ | .-~/								   #
#						   T\ Y	 I	|/	/  _							   #
#		  /T			   | \I	 |	I  Y.-~/							   #
#		 I l   /I		T\ |  |	 l	|  T  /								   #
#	  T\ |	\ Y l  /T	| \I  l	  \ `  l Y								   #
# __  | \l	 \l	 \I l __l  l   \   `  _. |								   #
# \ ~-l	 `\	  `\  \	 \ ~\  \   `. .-~	|								   #
#  \   ~-. "-.	`  \  ^._ ^. "-.  /	 \	 |								   #
#.--~-._  ~-  `	 _	~-_.-"-." ._ /._ ." ./								   #
# >--.	~-.	  ._  ~>-"	  "\   7   7   ]								   #
#^.___~"--._	~-{	 .-~ .	`\ Y . /	|								   #
# <__ ~"-.	~		/_/	  \	  \I  Y	  : |								   #
#	^-.__			~(_/   \   >._:	  | l______							   #
#		^--.,___.-~"  /_/	!  `-.~"--l_ /	   ~"-.						   #
#			   (_/ .  ~(   /'	  "~"--,Y	-=b-. _)					   #
#				(_/ .  \  Fire TV Guru/ l	   c"~o \					   #
#				 \ /	`.	  .		.^	 \_.-~"~--.	 )					   #
#				  (_/ .	  `	 /	   /	   !	   )/					   #
#				   / / _.	'.	 .':	  /		   '					   #
#				   ~(_/ .	/	 _	`  .-<_								   #
#					 /_/ . ' .-~" `.  / \  \		  ,z=.				   #
#					 ~( /	'  :   | K	 "-.~-.______//					   #
#					   "-,.	   l   I/ \_	__{--->._(==.				   #
#						//(		\  <	~"~"	 //						   #
#					   /' /\	 \	\	  ,v=.	((						   #
#					 .^. / /\	  "	 }__ //===-	 `						   #
#					/ / ' '	 "-.,__ {---(==-							   #
#				  .^ '		 :	T  ~"	ll								   #
#				 / .  .	 . : | :!		 \								   #
#				(_/	 /	 | | j-"		  ~^							   #
#				  ~-<_(_.^-~"											   #
#																		   #
############################################################################

#############################=IMPORTACIONES=######################################
#Kodi Specific
import xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
#Python Specific
import os, re, sys, xbmc, json, base64, string, urllib.request, urllib.parse, urllib.error, shutil, socket, time, hashlib
from urllib.parse import urlparse
#Addon Specific
from urllib.request import Request, urlopen
from resources.modules import control

##########################=VARIABLES=#######################################

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

# --- Caché basada en archivos para respuestas de API ---
ADDON_DATA = xbmcvfs.translatePath(os.path.join('special://home/userdata/addon_data/', ADDON_ID))
CACHE_DIR = os.path.join(ADDON_DATA, 'cache')
GET_SET = xbmcaddon.Addon(ADDON_ID)
ADDON_NAME = ADDON.getAddonInfo("name")
ICON   = xbmcvfs.translatePath(os.path.join('special://home/addons/' + ADDON_ID,  'icon.png'))
DIALOG = xbmcgui.Dialog()
DP  = xbmcgui.DialogProgress()
COLOR1='white'
COLOR2='blue'
dns_text = GET_SET.getSetting(id='DNS')

# ---------------------------------------------------------------------------
#  Caché de accesibilidad de hosts de iconos
# ---------------------------------------------------------------------------
_HOST_PROBE_CACHE_FILE = os.path.join(CACHE_DIR, 'host_probe_cache.json')
_HOST_TEST_TIMEOUT = 2              # segundos para la sonda de conexión TCP
_HOST_CACHE_TTL    = 3600          # volver a probar los hosts de iconos después de 1 hora (fijo)

def _load_host_cache():
    """Carga el caché persistente de prueba de hosts desde el disco."""
    try:
        if os.path.exists(_HOST_PROBE_CACHE_FILE):
            with open(_HOST_PROBE_CACHE_FILE, 'r') as f:
                raw = json.load(f)
            # Convierte las listas JSON [bool, float] de vuelta a tuplas (bool, float)
            return {k: (bool(v[0]), float(v[1])) for k, v in raw.items()}
    except Exception:
        pass
    return {}

def _save_host_cache(cache):
    """Persiste el caché de prueba de hosts en el disco."""
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(_HOST_PROBE_CACHE_FILE, 'w') as f:
            json.dump(cache, f)
    except Exception:
        pass

_host_reachable_cache = _load_host_cache()   # {hostname: (es_accesible, epoch)}

# ---------------------------------------------------------------------------
#  TTL de caché de contenido (minutos) — configurado por el usuario en Ajustes > Caché
# ---------------------------------------------------------------------------
_CONTENT_TTL_TEXT_MAP = {
    '5 minutes': 5, '15 minutes': 15, '30 minutes': 30,
    '1 hour': 60, '6 hours': 360, '12 hours': 720,
    '1 day': 1440, '7 days': 10080,
}
def _get_content_ttl(setting_id, default_minutes):
    try:
        val = GET_SET.getSetting(setting_id) or ''
        return _CONTENT_TTL_TEXT_MAP.get(val, default_minutes)
    except Exception:
        return default_minutes

CONTENT_CACHE_TTL_TV     = _get_content_ttl('tv_cache_ttl',     30)
CONTENT_CACHE_TTL_MOVIES = _get_content_ttl('movies_cache_ttl', 60)
CONTENT_CACHE_TTL_SERIES = _get_content_ttl('series_cache_ttl', 60)

# Hosts que siempre son accesibles (grandes CDN) — omitir la prueba
_TRUSTED_HOSTS = frozenset([
    'image.tmdb.org', 'www.themoviedb.org', 'themoviedb.org',
    'i.imgur.com', 'imgur.com',
])

def _test_host_reachable(hostname):
    """Devuelve True si *hostname* acepta una conexión TCP en el puerto 80."""
    now = time.time()
    if hostname in _host_reachable_cache:
        ok, ts = _host_reachable_cache[hostname]
        if now - ts < _HOST_CACHE_TTL:
            return ok
    try:
        sock = socket.create_connection((hostname, 80), timeout=_HOST_TEST_TIMEOUT)
        sock.close()
        _host_reachable_cache[hostname] = (True, now)
        _save_host_cache(_host_reachable_cache)
        return True
    except (socket.timeout, socket.error, OSError):
        xbmc.log('%s: host de icono %s inalcanzable – usando icono de respaldo' % (ADDON_ID, hostname), 2)
        _host_reachable_cache[hostname] = (False, now)
        _save_host_cache(_host_reachable_cache)
        return False

def safe_icon(iconimage, fallback=None):
    """Devuelve *iconimage* si su host es accesible; de lo contrario *fallback*."""
    if fallback is None:
        fallback = ICON
    if not iconimage:
        return fallback
    url_str = str(iconimage)
    if not url_str.startswith('http'):
        return url_str                      # ruta local — mantenerla
    try:
        parsed = urlparse(url_str)
        hostname = parsed.hostname
        if not hostname:
            return fallback
        if hostname in _TRUSTED_HOSTS:
            return url_str
        if _test_host_reachable(hostname):
            return url_str
        return fallback
    except Exception:
        return fallback

def check_protocol(url):
    parsed = urlparse(dns_text)
    protocol = parsed.scheme
    if protocol=='https':
        return url.replace('http','https')
    else:
        return url

def log(msg):
    msg = str(msg)
    xbmc.log('%s-%s'%(ADDON_ID,msg),2)

def b64(obj):
    return base64.b64decode(obj).decode('utf-8')

def percentage(part, whole):
    return 100 * float(part)/float(whole)

def getInfo(label):
    try: return xbmc.getInfoLabel(label)
    except: return False

def LogNotify(title, message, times=2000, icon=ICON, sound=False):
    DIALOG.notification(title, message, icon, int(times), sound)

def ASln():
    return LogNotify("[COLOR {0}]{1}[/COLOR]".format(COLOR1, ADDON_ID), '[COLOR {0}]AdvancedSettings.xml se ha escrito[/COLOR]'.format(COLOR2))

def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        try: r = re.search(r"(?i)" + from_string + r"([\S\s]+?)" + to_string, text).group(1)
        except: r = ''
    else:
        try: r = re.search(r"(?i)(" + from_string + r"[\S\s]+?" + to_string + ")", text).group(1)
        except: r = ''
    return r

def regex_get_all(text, start_with, end_with):
    r = re.findall(r"(?i)(" + start_with + r"[\S\s]+?" + end_with + ")", text)
    return r

def regex_get_us(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + ".+?[UK: Sky Sports].+?" + end_with + ")", text)
    return r

##########################=CLASE RECONNECTPLAYER=======================
class ReconnectPlayer(xbmc.Player):
    """
    Reproductor personalizado que reintenta la reproducción hasta un máximo
    de intentos cuando se detiene o ocurre un error.
    """
    def __init__(self, url, max_retries=5, listitem=None, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.url = url
        self.max_retries = max_retries
        self.retry_count = 0
        self._stopped = False
        self.listitem = listitem
        self._playback_started = False
        self._start_time = time.time()

    def play_with_retries(self):
        """Inicia la reproducción con reintentos."""
        self.retry_count = 0
        self._stopped = False
        self._playback_started = False
        
        # Iniciar reproducción directamente
        xbmc.log(f'IPTVXC: Iniciando reproducción...', xbmc.LOGINFO)
        self.play(self.url, self.listitem)
        
        # Esperar un poco para que comience
        for _ in range(10):
            xbmc.sleep(100)
            if self.isPlaying():
                self._playback_started = True
                xbmc.log('IPTVXC: Reproducción iniciada correctamente', xbmc.LOGINFO)
                return True
        
        xbmc.log('IPTVXC: No se pudo iniciar la reproducción', xbmc.LOGERROR)
        return False

    def onPlayBackStarted(self):
        """Se llama cuando la reproducción comienza."""
        self._playback_started = True
        self._start_time = time.time()
        xbmc.log('IPTVXC: Playback started', xbmc.LOGINFO)

    def onPlayBackStopped(self):
        """Se llama cuando la reproducción se detiene."""
        self._stopped = True
        playback_time = time.time() - self._start_time
        xbmc.log(f'IPTVXC: Playback stopped after {playback_time:.2f} seconds', xbmc.LOGINFO)

    def onPlayBackEnded(self):
        """Se llama cuando la reproducción termina normalmente."""
        self._stopped = True
        playback_time = time.time() - self._start_time
        xbmc.log(f'IPTVXC: Playback ended normally after {playback_time:.2f} seconds', xbmc.LOGINFO)

    def onPlayBackError(self):
        """Se llama cuando hay un error de reproducción."""
        self._stopped = True
        xbmc.log('IPTVXC: Playback error detected', xbmc.LOGERROR)

    def onPlayBackStarted(self):
        """Se llama cuando la reproducción comienza."""
        self._playback_started = True
        self._start_time = time.time()
        xbmc.log('IPTVXC: Playback started', xbmc.LOGINFO)

    def onPlayBackStopped(self):
        """Se llama cuando la reproducción se detiene."""
        self._stopped = True
        playback_time = time.time() - self._start_time
        xbmc.log(f'IPTVXC: Playback stopped after {playback_time:.2f} seconds', xbmc.LOGINFO)
        
        # Si la reproducción duró menos de 10 segundos y hay reintentos disponibles
        if playback_time < 10 and self.retry_count < self.max_retries and not self._playback_started:
            xbmc.log(f'IPTVXC: Reproducción muy corta, reintentando ({self.retry_count+1}/{self.max_retries})', xbmc.LOGNOTICE)
            self.retry_count += 1
            xbmc.sleep(2000)
            self.play(self.url, self.listitem)

    def onPlayBackEnded(self):
        """Se llama cuando la reproducción termina normalmente."""
        self._stopped = True
        playback_time = time.time() - self._start_time
        xbmc.log(f'IPTVXC: Playback ended normally after {playback_time:.2f} seconds', xbmc.LOGINFO)

    def onPlayBackError(self):
        """Se llama cuando hay un error de reproducción."""
        self._stopped = True
        xbmc.log('IPTVXC: Playback error detected', xbmc.LOGERROR)
        
        if self.retry_count < self.max_retries:
            xbmc.log(f'IPTVXC: Error, reintentando ({self.retry_count+1}/{self.max_retries})', xbmc.LOGNOTICE)
            self.retry_count += 1
            xbmc.sleep(3000)  # Esperar 3 segundos después de un error
            self.play(self.url, self.listitem)

##########################=FUNCIONES DE INTERFAZ=============================
def addDir(name, url, mode, iconimage, fanart, description):
    # Usa el icono local del addon en el parámetro de la URL del plugin para evitar que
    # el CCurlFile interno de Kodi obtenga una URL de icono remota al detener/reanudar,
    # lo que causa una congelación de la UI de 30 segundos cuando el servidor de iconos es lento/está caído.
    # El arte de ListItem a continuación todavía usa el icono de canal real (posiblemente remoto).
    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(str(url))+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(str(name))+"&iconimage="+urllib.parse.quote_plus(str(ICON))+"&description="+urllib.parse.quote_plus(str(description))
    try:
        xbmc.log('%s: addDir name=%s mode=%s url=%s' % (ADDON_ID, str(name)[:80], str(mode), str(url)[:160]), 1)
    except Exception:
        pass
    ok=True
    # Usa safe_icon para evitar que Kodi se bloquee en servidores de iconos inalcanzables
    safe_img = safe_icon(iconimage)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'icon':safe_img, 'thumb':safe_img})
    liz.setInfo( type="Video", infoLabels={"Title": name, "Plot": description,})
    liz.setProperty('fanart_image', fanart)
    # Menú contextual de Favoritos
    cm = []
    _fav_modes = (2, 3, 4, 12, 13, 18, 19, 20, 25)
    try:
        if int(mode) in _fav_modes:
            fav_url = sys.argv[0] + "?mode=31&url=" + urllib.parse.quote_plus(str(url)) + "&name=" + urllib.parse.quote_plus(str(name)) + "&iconimage=" + urllib.parse.quote_plus(str(iconimage)) + "&description=" + urllib.parse.quote_plus(str(description)) + "&fav_mode=" + str(mode)
            if is_favorite(url):
                cm.append(('[COLOR red]Eliminar de Favoritos[/COLOR]', 'RunPlugin(' + fav_url + ')'))
            else:
                cm.append(('[COLOR gold]Añadir a Favoritos[/COLOR]', 'RunPlugin(' + fav_url + ')'))
    except Exception:
        pass
    if cm:
        liz.addContextMenuItems(cm)
    if mode==4:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    elif mode==7 or mode==10 or mode==17 or mode==21:
        liz.setInfo( type="Video", infoLabels={"Title": name, "Plot": description})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    else:
        liz.setInfo( type="Video", infoLabels={"Title": name, "Plot": description})
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    return ok

def addDirMeta(name, url, mode, iconimage, fanart, description, year, cast, rating, runtime, genre):
    # Extrae el ID de TMDB de la descripción si está disponible
    tmdb_id = ''
    if description:
        # Intenta primero con el patrón decodificado de URL (TMDB_ID: 1525091)
        tmdb_match = re.search(r'TMDB_ID[:\s]+(\d+)', description)
        if tmdb_match:
            tmdb_id = tmdb_match.group(1)
            xbmc.log('[IPTVXC] ID TMDB extraído: %s de la descripción' % tmdb_id, xbmc.LOGDEBUG)
        else:
            xbmc.log('[IPTVXC] No se encontró ID TMDB en la descripción (primeros 200 caracteres): %s' % description[:200], xbmc.LOGDEBUG)

    u=sys.argv[0]+"?url="+urllib.parse.quote_plus(str(url))+"&mode="+str(mode)+"&name="+urllib.parse.quote_plus(str(name))+"&iconimage="+urllib.parse.quote_plus(str(ICON))+"&description="+urllib.parse.quote_plus(str(description))+"&year="+urllib.parse.quote_plus(str(year))+"&tmdb_id="+urllib.parse.quote_plus(str(tmdb_id))
    ok=True
    # Usa safe_icon para evitar que Kodi se bloquee en servidores de iconos inalcanzables
    safe_img = safe_icon(iconimage)
    liz=xbmcgui.ListItem(name)
    liz.setArt({'icon':safe_img, 'thumb':safe_img})
    liz.setInfo( type="Video", infoLabels={"Title": name, "Plot": description, "Rating": rating, "Year": year, "Duration": runtime, "Cast": cast, "Genre": genre})
    liz.setProperty('fanart_image', fanart)
    liz.setProperty("IsPlayable","true")
    cm = []
    cm.append(('Información de la Película', 'XBMC.Action(Info)'))

    # Añade elementos del menú contextual de Trakt si está habilitado
    try:
        if GET_SET.getSetting('trakt_enabled') == 'true':
            # Añadir a la lista de seguimiento de Trakt
            trakt_watchlist_url = sys.argv[0]+"?url=TRAKT_WATCHLIST&mode=23&name="+urllib.parse.quote_plus(str(name))+"&year="+str(year)
            cm.append(('Añadir a la Lista de Seguimiento de Trakt', 'RunPlugin('+trakt_watchlist_url+')'))

            # Marcar como visto en Trakt
            trakt_watched_url = sys.argv[0]+"?url=TRAKT_WATCHED&mode=23&name="+urllib.parse.quote_plus(str(name))+"&year="+str(year)
            cm.append(('Marcar como Visto en Trakt', 'RunPlugin('+trakt_watched_url+')'))
    except:
        pass

    # Menú contextual de Favoritos
    fav_url = sys.argv[0] + "?mode=31&url=" + urllib.parse.quote_plus(str(url)) + "&name=" + urllib.parse.quote_plus(str(name)) + "&iconimage=" + urllib.parse.quote_plus(str(iconimage)) + "&description=" + urllib.parse.quote_plus(str(description)) + "&fav_mode=" + str(mode)
    if is_favorite(url):
        cm.append(('[COLOR red]Eliminar de Favoritos[/COLOR]', 'RunPlugin(' + fav_url + ')'))
    else:
        cm.append(('[COLOR gold]Añadir a Favoritos[/COLOR]', 'RunPlugin(' + fav_url + ')'))

    liz.addContextMenuItems(cm, replaceItems=True)
    if mode==19 or mode==20:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=True)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok

##########################=FUNCIONES DE RED==================================
def OPEN_URL(url):
    # Caché simple en memoria para evitar llamadas de red repetidas en un breve intervalo de tiempo
    try:
        cache = OPEN_URL._cache
        cache_time = OPEN_URL._cache_time
    except AttributeError:
        OPEN_URL._cache = {}
        OPEN_URL._cache_time = {}
        cache = OPEN_URL._cache
        cache_time = OPEN_URL._cache_time

    ttl_seconds = 5
    now = time.time()
    if url in cache and (now - cache_time.get(url, 0)) < ttl_seconds:
        return cache[url]

    try:
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:53.0) Gecko/20100101 Firefox/53.0')
        response = urlopen(req, timeout=15)
        link = response.read().decode('utf-8')
        response.close()
        # Limpia cualquier error anterior
        OPEN_URL._last_error = None
        cache[url] = link
        cache_time[url] = now
        return link
    except Exception as e:
        # Almacena la última excepción para que los llamantes la inspeccionen (útil para el manejo de códigos de estado HTTP)
        OPEN_URL._last_error = e
        try:
            xbmc.log('%s-OPEN_URL error para %s: %s' % (ADDON_ID, url, e), 2)
        except Exception:
            pass
        return ''

def _ensure_cache_dir():
    """Crea el directorio de caché de archivos del addon si no existe."""
    if not os.path.exists(CACHE_DIR):
        try:
            os.makedirs(CACHE_DIR)
        except Exception:
            pass

def _cache_key(url):
    """Devuelve un resumen MD5 hexadecimal de la URL para usar como nombre de archivo de caché."""
    return hashlib.md5(url.encode('utf-8')).hexdigest()

def OPEN_URL_CACHED(url, ttl_minutes=30):
    """Obtiene URL con caché persistente basada en archivos."""
    _ensure_cache_dir()
    key = _cache_key(url)
    cache_file = os.path.join(CACHE_DIR, key + '.dat')

    # Verifica si hay un acierto de caché reciente
    if os.path.exists(cache_file):
        try:
            age = time.time() - os.path.getmtime(cache_file)
            if age < (ttl_minutes * 60):
                with open(cache_file, 'r', encoding='utf-8') as f:
                    data = f.read()
                if data:
                    xbmc.log('%s: ACIERTO de caché para %s (edad: %ds)' % (ADDON_ID, url[:80], int(age)), 1)
                    return data
        except Exception:
            pass

    # Fallo de caché o expirado — obtiene de la red
    data = OPEN_URL(url)
    if data:
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(data)
            xbmc.log('%s: ALMACENANDO en caché para %s' % (ADDON_ID, url[:80]), 1)
        except Exception:
            pass
    return data

def clear_addon_cache():
    """Elimina todos los archivos en el directorio de caché de archivos del addon."""
    _ensure_cache_dir()
    count = 0
    try:
        for f in os.listdir(CACHE_DIR):
            fp = os.path.join(CACHE_DIR, f)
            if os.path.isfile(fp):
                os.remove(fp)
                count += 1
        xbmc.log('%s: Caché de archivos del addon limpiada (%d archivos)' % (ADDON_ID, count), 1)
    except Exception:
        pass
    return count

def clear_cache():
    xbmc.log('LIMPIEZA DE CACHÉ ACTIVADA')
    # Siempre limpia la caché de archivos del addon
    clear_addon_cache()
    # También limpia la caché de la aplicación Kodi
    xbmc_cache_path = os.path.join(xbmc.translatePath('special://home'), 'cache')
    confirm = xbmcgui.Dialog().yesno("Por favor confirma", "¿Limpiar la caché de datos del addon y la caché de la aplicación Kodi?")
    if confirm:
        if os.path.exists(xbmc_cache_path) == True:
            for root, dirs, files in os.walk(xbmc_cache_path):
                file_count = 0
                file_count += len(files)
                if file_count > 0:
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass
                        for d in dirs:
                            try:
                                shutil.rmtree(os.path.join(root, d))
                            except:
                                pass
        LogNotify("[COLOR {0}]{1}[/COLOR]".format(COLOR1, ADDON_NAME), '[COLOR {0}]¡Caché Limpiada Exitosamente![/COLOR]'.format(COLOR2))
        xbmc.executebuiltin("Container.Refresh()")
    else:
        LogNotify("[COLOR {0}]{1}[/COLOR]".format(COLOR1, ADDON_NAME), '[COLOR {0}]Caché del addon limpiada[/COLOR]'.format(COLOR2))
        xbmc.executebuiltin("Container.Refresh()")

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

def getlocalip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(('8.8.8.8', 0))
    s = s.getsockname()[0]
    return s

def getexternalip():
    import json
    url = urllib.request.urlopen("https://api.ipify.org/?format=json")
    data = json.loads(url.read().decode())
    return str(data["ip"])

def MonthNumToName(num):
    if '01' in num:
        month = 'Enero'
    elif '02' in num:
        month = 'Febrero'
    elif '03' in num:
        month = 'Marzo'
    elif '04' in num:
        month = 'Abril'
    elif '05' in num:
        month = 'Mayo'
    elif '06' in num:
        month = 'Junio'
    elif '07' in num:
        month = 'Julio'
    elif '08' in num:
        month = 'Agosto'
    elif '09' in num:
        month = 'Septiembre'
    elif '10' in num:
        month = 'Octubre'
    elif '11' in num:
        month = 'Noviembre'
    elif '12' in num:
        month = 'Diciembre'
    return month

def killxbmc():
    killdialog = xbmcgui.Dialog().yesno('Forzar Cierre de Kodi', '[COLOR white]Estás a punto de cerrar Kodi', '¿Quieres continuar?[/COLOR]', nolabel='[B][COLOR red] No Cancelar[/COLOR][/B]', yeslabel='[B][COLOR green]Forzar Cierre de Kodi[/COLOR][/B]')
    if killdialog:
        os._exit(1)

def gen_m3u(url, path):
    try:
        response = OPEN_URL(url)
        if not response:
            DIALOG.ok(ADDON_NAME, 'No se pudo obtener datos')
            return
        parse = json.loads(response)
    except Exception as e:
        DIALOG.ok(ADDON_NAME, f'Error al parsear JSON: {e}')
        return

    i=1
    DP.create(ADDON_NAME, "Por favor espera")
    with open (path, 'w+', encoding="utf-8") as ftg:
        ftg.write('#EXTM3U\n')
        for items in parse['available_channels']:
            a = parse['available_channels'][items]

            if a['stream_type'] == 'live':

                b = '#EXTINF:-1 channel-id="{0}" tvg-id="{1}" tvg-name="{2}" tvg-logo="{3}" channel-id="{4}" group-title="{5}",{6}'.format(i, a['epg_channel_id'], a['epg_channel_id'], a['stream_icon'], a['name'], a['category_name'], a['name'])

                if parse['server_info']['server_protocol'] == 'https':
                    port = parse['server_info']['https_port']
                else:
                    port = parse['server_info']['port']

                dns = '{0}://{1}:{2}'.format(parse['server_info']['server_protocol'], parse['server_info']['url'], port)
                c = '{0}/{1}/{2}/{3}'.format(dns, parse['user_info']['username'], parse['user_info']['password'], a['stream_id'])
                ftg.write(b+'\n'+c+'\n')
                i +=1
                DP.update(int(100), 'Canal encontrado \n' + a['name'] + '\n')
                if DP.iscanceled(): break
        DP.close()
        DIALOG.ok(ADDON_NAME, 'Se encontraron ' + str(i) + ' Canales')

def gen_m3u_silent(url, path):
    """Regenera M3U sin ningún diálogo (para uso en segundo plano/inicio)."""
    try:
        parse = json.loads(OPEN_URL(url))
    except Exception:
        return
    i = 1
    with open(path, 'w+', encoding='utf-8') as ftg:
        ftg.write('#EXTM3U\n')
        for items in parse.get('available_channels', {}):
            a = parse['available_channels'][items]
            if a.get('stream_type') == 'live':
                b = '#EXTINF:-1 channel-id="{0}" tvg-id="{1}" tvg-name="{2}" tvg-logo="{3}" channel-id="{4}" group-title="{5}",{6}'.format(
                    i, a.get('epg_channel_id',''), a.get('epg_channel_id',''), a.get('stream_icon',''),
                    a.get('name',''), a.get('category_name',''), a.get('name',''))
                if parse['server_info']['server_protocol'] == 'https':
                    port = parse['server_info']['https_port']
                else:
                    port = parse['server_info']['port']
                dns = '{0}://{1}:{2}'.format(parse['server_info']['server_protocol'], parse['server_info']['url'], port)
                c = '{0}/{1}/{2}/{3}'.format(dns, parse['user_info']['username'], parse['user_info']['password'], a['stream_id'])
                ftg.write(b + '\n' + c + '\n')
                i += 1

# Nuevo helper: verificador de endpoints multi-etapa
try:
    import requests
    exist_requests = True
except Exception:
    exist_requests = False
    # Recurre a urllib si requests no está disponible
from urllib.error import HTTPError, URLError


def get_working_endpoint(base_url, user, password, timeout=10, retries=2, treat_512_as_invalid=True, notify=True):
    """Intenta una secuencia de endpoints y devuelve el primer endpoint funcional."""
    endpoints = [
        f"{base_url}/player_api.php?username={user}&password={password}",
        f"{base_url}/panel_api.php?username={user}&password={password}",
        f"{base_url}/api.php?username={user}&password={password}",
        f"{base_url}/get.php?username={user}&password={password}&type=m3u_plus&output=ts",
        f"{base_url}/client_area/player_api.php?username={user}&password={password}",
    ]
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

    for attempt in range(1, retries+1):
        for url in endpoints:
            xbmc.log(f'{ADDON_ID}: get_working_endpoint intento {attempt} -> {url}', 1)
            try:
                if exist_requests:
                    resp = requests.get(url, headers=headers, timeout=timeout)
                    code = resp.status_code
                    content = resp.text
                else:
                    req = Request(url)
                    req.add_header('User-Agent', headers['User-Agent'])
                    resp = urlopen(req, timeout=timeout)
                    code = resp.getcode()
                    content = resp.read().decode('utf-8')
            except HTTPError as he:
                code = getattr(he, 'code', None)
                content = ''
                OPEN_URL._last_error = he
                xbmc.log(f'{ADDON_ID}: HTTPError {code} para {url}', 1)
            except URLError as ue:
                OPEN_URL._last_error = ue
                xbmc.log(f'{ADDON_ID}: URLError para {url}: {ue}', 1)
                continue
            except Exception as e:
                OPEN_URL._last_error = e
                xbmc.log(f'{ADDON_ID}: Excepción para {url}: {e}', 1)
                continue

            if code == 200:
                if content and ('#EXTM3U' in content):
                    if notify:
                        xbmc.log(f'{ADDON_ID}: M3U encontrada en {url}', 1)
                    return {'url': url, 'type': 'm3u', 'status': code, 'data': content}
                try:
                    j = json.loads(content)
                    if isinstance(j, dict) and 'user_info' in j:
                        if notify:
                            xbmc.log(f'{ADDON_ID}: JSON válido encontrado en {url}', 1)
                        return {'url': url, 'type': 'json', 'status': code, 'data': j}
                except Exception:
                    pass

            if code in (401, 403) or (treat_512_as_invalid and code == 512):
                xbmc.log(f'{ADDON_ID}: Credenciales inválidas detectadas (HTTP {code}) en {url}', 1)
                if notify:
                    xbmcgui.Dialog().ok(ADDON_NAME, 'Prueba Fallida\nDNS o Credenciales de Acceso Inválidos')
                return {'url': url, 'type': None, 'status': code, 'data': None, 'error': 'invalid_credentials'}
            if code == 512:
                xbmc.log(f'{ADDON_ID}: Posible Problema de Cuenta/MAC (HTTP 512) en {url}', 1)
                continue
            if code >= 400:
                xbmc.log(f'{ADDON_ID}: Error HTTP {code} en {url}', 1)
                if notify:
                    xbmcgui.Dialog().ok(ADDON_NAME, f'Error HTTP {code} al probar las credenciales')
                return {'url': url, 'type': None, 'status': code, 'data': None, 'error': 'http_error'}

    msg = 'Fallaron todas las pruebas de endpoint. Por favor, verifica DNS, credenciales y conectividad de red.'
    xbmc.log(f'{ADDON_ID}: {msg}', 1)
    if notify:
        xbmcgui.Dialog().ok(ADDON_NAME, msg)
    return None

# -- Ayudantes de expiración de cuenta --
import threading, datetime

def get_account_expiry_info(base_url=None, user=None, password=None, timeout=8):
    """Devuelve un dict con información de expiración."""
    try:
        if base_url is None:
            base_url = GET_SET.getSetting('DNS')
        if user is None:
            user = GET_SET.getSetting('Username')
        if password is None:
            password = GET_SET.getSetting('Password')
    except Exception:
        pass

    if not (base_url and user and password):
        return {'error': 'missing_credentials'}

    try:
        res = get_working_endpoint(base_url, user, password, timeout=timeout, retries=1, treat_512_as_invalid=False, notify=False)
    except Exception as e:
        return {'error': f'endpoint_error: {e}'}

    if not res:
        return {'error': 'no_endpoint'}

    if res.get('type') != 'json':
        return {'error': 'no_json'}

    data = res.get('data') or {}
    ui = data.get('user_info', {})
    exp = ui.get('exp_date', '')
    try:
        if not exp or str(exp).strip() == '' or int(exp) == 0:
            return {'unlimited': True}
        ts = int(exp)
        now = int(time.time())
        days = int((ts - now) / 86400)
        return {'days': days, 'expiry_ts': ts, 'unlimited': False}
    except Exception as e:
        return {'error': f'parse_error: {e}'}


def notify_account_expiry(threshold_days=None, show_dialog=False):
    """Verifica la expiración de la cuenta y notifica al usuario si está dentro del umbral."""
    try:
        enabled = GET_SET.getSetting('expiry_notify_enabled') == 'true'
        if not enabled:
            return False
        if threshold_days is None:
            try:
                threshold_days = int(GET_SET.getSetting('expiry_notify_days'))
            except Exception:
                threshold_days = 7
    except Exception:
        return False

    info = get_account_expiry_info()
    if info.get('unlimited'):
        return False
    if 'error' in info:
        return False

    days = info.get('days')
    ts = info.get('expiry_ts')
    if days is None:
        return False

    date_str = datetime.datetime.fromtimestamp(int(ts)).strftime('%d/%m/%Y') if ts else 'Desconocida'

    if days < 0:
        msg = f'La cuenta expiró hace {-days} días el {date_str}'
        if show_dialog:
            xbmcgui.Dialog().ok(ADDON_NAME, msg)
        else:
            LogNotify(f"{ADDON_NAME} - Cuenta Expirada", msg, times=5000)
        return True

    if days <= threshold_days:
        msg = f'La cuenta expira en {days} día(s) el {date_str}'
        if days <= 2 or show_dialog:
            xbmcgui.Dialog().ok(ADDON_NAME, msg)
        else:
            LogNotify(f"{ADDON_NAME} - Aviso de Expiración", msg, times=5000)
        return True

    return False


def start_expiry_background_check(interval_hours=None):
    """Inicia un hilo en segundo plano que verifica periódicamente la expiración mientras el addon se ejecuta."""
    try:
        if interval_hours is None:
            interval_hours = int(GET_SET.getSetting('expiry_notify_interval_hours') or 24)
        else:
            interval_hours = int(interval_hours)
    except Exception:
        interval_hours = 24

    if interval_hours < 1:
        interval_hours = 1

    xbmc.log(f'{ADDON_ID}: Iniciando verificación de expiración en segundo plano cada {interval_hours} hora(s)', 1)

    def _worker():
        t = threading.current_thread()
        total_seconds = max(1, int(interval_hours * 3600))
        while getattr(t, 'running', True):
            try:
                notify_account_expiry()
            except Exception:
                pass
            for _ in range(total_seconds):
                if not getattr(t, 'running', True):
                    break
                xbmc.sleep(1000)

    thr = threading.Thread(target=_worker, name='IPTVXC-ExpiryCheck', daemon=True)
    thr.running = True
    thr.start()
    return thr


# ---------------------------------------------------------------------------
#  Sistema de Favoritos
# ---------------------------------------------------------------------------
FAVORITES_FILE = os.path.join(ADDON_DATA, 'favorites.json')

def load_favorites():
    try:
        if os.path.exists(FAVORITES_FILE):
            with open(FAVORITES_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return []

def save_favorites(favs):
    try:
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(FAVORITES_FILE, 'w', encoding='utf-8') as f:
            json.dump(favs, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def add_favorite(url, name, mode, iconimage, fanart, description):
    favs = load_favorites()
    for fav in favs:
        if fav.get('url') == url:
            return False
    favs.append({
        'url': url, 'name': name, 'mode': int(mode),
        'iconimage': iconimage, 'fanart': fanart,
        'description': description
    })
    save_favorites(favs)
    return True

def remove_favorite(url):
    favs = load_favorites()
    favs = [f for f in favs if f.get('url') != url]
    save_favorites(favs)

def is_favorite(url):
    favs = load_favorites()
    return any(f.get('url') == url for f in favs)


# ---------------------------------------------------------------------------
#  Historial de Vistos Recientemente
# ---------------------------------------------------------------------------
HISTORY_FILE = os.path.join(ADDON_DATA, 'history.json')

def load_history():
    try:
        if os.path.exists(HISTORY_FILE):
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return []

def save_history(history):
    try:
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def add_to_history(url, name, iconimage, description):
    history = load_history()
    history = [h for h in history if h.get('url') != url]
    history.insert(0, {
        'url': url, 'name': name,
        'iconimage': iconimage, 'description': description,
        'timestamp': time.time()
    })
    try:
        max_items = int(GET_SET.getSetting('max_history_items') or '25')
    except Exception:
        max_items = 25
    history = history[:max_items]
    save_history(history)

def clear_history():
    save_history([])


# ---------------------------------------------------------------------------
#  Último Reproducido (para reanudación automática)
# ---------------------------------------------------------------------------
LAST_PLAYED_FILE = os.path.join(ADDON_DATA, 'last_played.json')

def save_last_played(url, name, iconimage, description):
    try:
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(LAST_PLAYED_FILE, 'w', encoding='utf-8') as f:
            json.dump({
                'url': url, 'name': name,
                'iconimage': iconimage, 'description': description,
                'timestamp': time.time()
            }, f, ensure_ascii=False)
    except Exception:
        pass

def load_last_played():
    try:
        if os.path.exists(LAST_PLAYED_FILE):
            with open(LAST_PLAYED_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return None


# ---------------------------------------------------------------------------
#  Perfiles de Servidor
# ---------------------------------------------------------------------------
PROFILES_FILE = os.path.join(ADDON_DATA, 'profiles.json')

def load_profiles():
    try:
        if os.path.exists(PROFILES_FILE):
            with open(PROFILES_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        pass
    return []

def save_profiles(profiles):
    try:
        os.makedirs(ADDON_DATA, exist_ok=True)
        with open(PROFILES_FILE, 'w', encoding='utf-8') as f:
            json.dump(profiles, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def save_current_as_profile(profile_name):
    profiles = load_profiles()
    dns = GET_SET.getSetting('DNS')
    user = GET_SET.getSetting('Username')
    pw = GET_SET.getSetting('Password')
    if not (dns and user):
        return False
    for p in profiles:
        if p.get('name') == profile_name:
            p['dns'] = dns
            p['username'] = user
            p['password'] = pw
            save_profiles(profiles)
            return True
    profiles.append({
        'name': profile_name,
        'dns': dns,
        'username': user,
        'password': pw
    })
    save_profiles(profiles)
    return True

def switch_profile(index):
    profiles = load_profiles()
    if 0 <= index < len(profiles):
        p = profiles[index]
        GET_SET.setSetting('DNS', p['dns'])
        GET_SET.setSetting('Username', p['username'])
        GET_SET.setSetting('Password', p['password'])
        clear_addon_cache()
        return p['name']
    return None

def delete_profile(index):
    profiles = load_profiles()
    if 0 <= index < len(profiles):
        removed = profiles.pop(index)
        save_profiles(profiles)
        return removed.get('name', '')
    return None

##########################=FUNCIONES DE GENERACIÓN M3U=======================
def generate_live_m3u():
    """Genera M3U para canales en vivo."""
    json_path = os.path.join(ADDON_DATA, 'live_streams.json')
    m3u_path = os.path.join(ADDON_DATA, 'tv.m3u')
    
    if not os.path.exists(json_path):
        log('generate_live_m3u: no existe live_streams.json')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        items = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    items = v
                    break

        if not items:
            return

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            dns = GET_SET.getSetting('DNS')
            user = GET_SET.getSetting('Username')
            pw = GET_SET.getSetting('Password')
            for item in items:
                if not isinstance(item, dict):
                    continue
                name = item.get('name', '')
                if not name:
                    continue
                stream_id = item.get('stream_id', '')
                logo = item.get('stream_icon', '')
                group = item.get('category_name', '')
                epg_id = item.get('epg_channel_id', '')
                tvg_id = epg_id if epg_id else str(stream_id)
                url = f'{dns}/{user}/{pw}/{stream_id}'
                m3u.write(f'#EXTINF:-1 tvg-id="{tvg_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n{url}\n')
        log(f'generate_live_m3u: OK')
    except Exception as e:
        log(f'generate_live_m3u: error {e}')

def generate_vod_m3u():
    """Genera M3U básico para películas."""
    json_path = os.path.join(ADDON_DATA, 'vod_streams.json')
    m3u_path = os.path.join(ADDON_DATA, 'movies.m3u')
    
    if not os.path.exists(json_path):
        log('generate_vod_m3u: no existe vod_streams.json')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        items = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    items = v
                    break

        if not items:
            return

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            dns = GET_SET.getSetting('DNS')
            user = GET_SET.getSetting('Username')
            pw = GET_SET.getSetting('Password')
            for item in items:
                if not isinstance(item, dict):
                    continue
                name = item.get('name', '')
                if not name:
                    continue
                stream_id = item.get('stream_id', '')
                logo = item.get('stream_icon', '')
                group = item.get('category_name', '')
                ext = item.get('container_extension', 'mp4')
                url = f'{dns}/movie/{user}/{pw}/{stream_id}.{ext}'
                m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n{url}\n')
        log(f'generate_vod_m3u: OK')
    except Exception as e:
        log(f'generate_vod_m3u: error {e}')

def generate_series_m3u():
    """Genera M3U básico para series."""
    json_path = os.path.join(ADDON_DATA, 'series_list.json')
    m3u_path = os.path.join(ADDON_DATA, 'series.m3u')
    
    if not os.path.exists(json_path):
        log('generate_series_m3u: no existe series_list.json')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        items = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    items = v
                    break

        if not items:
            return

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            for item in items:
                if not isinstance(item, dict):
                    continue
                name = item.get('name', '')
                if not name:
                    continue
                series_id = item.get('series_id', '')
                logo = item.get('cover', '')
                group = item.get('category_name', '')
                m3u.write(f'#EXTINF:-1 tvg-id="{series_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n\n')
        log(f'generate_series_m3u: OK')
    except Exception as e:
        log(f'generate_series_m3u: error {e}')

def generate_series_menu():
    """Menú de generación de series."""
    opciones = [
        '[COLOR lime]Solo títulos de series[/COLOR] (rápido)',
        '[COLOR orange]Series + Temporadas[/COLOR] (medio)',
        '[COLOR red]COMPLETO - Todos los episodios[/COLOR] (lento)'
    ]
    seleccion = DIALOG.select('Generar M3U de Series', opciones)

    if seleccion == 0:
        generate_series_titles_only()
    elif seleccion == 1:
        generate_series_with_seasons()
    elif seleccion == 2:
        if DIALOG.yesno(ADDON_NAME, '¿Continuar? Puede tomar varios minutos'):
            generate_complete_series_m3u()

def generate_series_titles_only():
    """Genera M3U solo con títulos de series."""
    json_path = os.path.join(ADDON_DATA, 'series_list.json')
    m3u_path = os.path.join(ADDON_DATA, 'series_titles.m3u')

    if not os.path.exists(json_path):
        DIALOG.ok(ADDON_NAME, 'Primero entra en Series')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        series_list = []
        if isinstance(data, list):
            series_list = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    series_list = v
                    break

        dns = GET_SET.getSetting('DNS')
        user = GET_SET.getSetting('Username')
        pw = GET_SET.getSetting('Password')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            for serie in series_list:
                if not isinstance(serie, dict):
                    continue
                name = serie.get('name', '')
                series_id = serie.get('series_id', '')
                logo = serie.get('cover', '')
                group = serie.get('category_name', '')
                m3u.write(f'#EXTINF:-1 tvg-id="{series_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n\n')
        DIALOG.notification(ADDON_NAME, 'Lista generada', ICON, 3000)
    except Exception as e:
        log(f'Error: {e}')
        DIALOG.ok(ADDON_NAME, f'Error: {str(e)}')

def generate_series_with_seasons():
    """Genera M3U con series y temporadas."""
    DIALOG.ok(ADDON_NAME, "Función en desarrollo")

def generate_complete_series_m3u():
    """Genera M3U completo con todos los episodios."""
    DIALOG.ok(ADDON_NAME, "Función en desarrollo")

##########################=FUNCIONES DE PELÍCULAS=======================
##########################=FUNCIONES DE PELÍCULAS=======================
def generate_movies_titles_only():
    """Genera M3U solo con títulos de películas."""
    json_path = os.path.join(ADDON_DATA, 'vod_streams.json')
    m3u_path = os.path.join(ADDON_DATA, 'movies_titles.m3u')

    if not os.path.exists(json_path):
        DIALOG.ok(ADDON_NAME, 'Primero entra en Películas')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        movies_list = []
        if isinstance(data, list):
            movies_list = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    movies_list = v
                    break

        dns = GET_SET.getSetting('DNS')
        user = GET_SET.getSetting('Username')
        pw = GET_SET.getSetting('Password')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            for movie in movies_list:
                if not isinstance(movie, dict):
                    continue
                name = movie.get('name', '')
                stream_id = movie.get('stream_id', '')
                logo = movie.get('stream_icon', '')
                group = movie.get('category_name', '')
                ext = movie.get('container_extension', 'mp4')
                url = f"{dns}/movie/{user}/{pw}/{stream_id}.{ext}"
                m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n{url}\n\n')
        DIALOG.notification(ADDON_NAME, 'Lista generada', ICON, 3000)
    except Exception as e:
        log(f'Error: {e}')
        DIALOG.ok(ADDON_NAME, f'Error: {str(e)}')

def generate_movies_basic_meta():
    """Genera M3U con metadatos básicos (año y descripción)."""
    json_path = os.path.join(ADDON_DATA, 'vod_streams.json')
    m3u_path = os.path.join(ADDON_DATA, 'movies_basic.m3u')

    if not os.path.exists(json_path):
        DIALOG.ok(ADDON_NAME, 'Primero entra en Películas')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        movies_list = []
        if isinstance(data, list):
            movies_list = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    movies_list = v
                    break

        dns = GET_SET.getSetting('DNS')
        user = GET_SET.getSetting('Username')
        pw = GET_SET.getSetting('Password')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write('# Lista de películas con metadatos básicos (año y descripción)\n\n')
            
            for movie in movies_list:
                if not isinstance(movie, dict):
                    continue
                name = movie.get('name', '')
                stream_id = movie.get('stream_id', '')
                logo = movie.get('stream_icon', '')
                group = movie.get('category_name', '')

                # Obtener sinopsis/plot
                plot = movie.get('plot', '')
                if not plot and 'description' in movie:
                    plot = movie.get('description', '')
                if not plot and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        plot = info.get('plot', '') or info.get('description', '')
                
                # Obtener año
                year = movie.get('year', '')
                if not year:
                    # Intentar extraer del nombre
                    year_match = re.search(r'\((\d{4})\)', name)
                    if year_match:
                        year = year_match.group(1)
                    # Intentar de releaseDate
                    elif 'releaseDate' in movie:
                        release = movie.get('releaseDate', '')
                        if release and len(release) >= 4:
                            year = release[:4]

                ext = movie.get('container_extension', 'mp4')
                url = f"{dns}/movie/{user}/{pw}/{stream_id}.{ext}"

                # Escribir línea EXTINF
                if group and group != 'Sin categoría':
                    m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n')
                else:
                    m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}",{name}\n')
                
                # Añadir metadatos
                if plot:
                    plot_clean = plot.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTDESC:{plot_clean}\n')
                if year:
                    m3u.write(f'#EXTYEAR:{year}\n')
                m3u.write(f'{url}\n\n')
        DIALOG.notification(ADDON_NAME, 'Lista generada', ICON, 3000)
    except Exception as e:
        log(f'Error: {e}')
        DIALOG.ok(ADDON_NAME, f'Error: {str(e)}')

def generate_movies_complete_meta():
    """Genera M3U con metadatos completos."""
    json_path = os.path.join(ADDON_DATA, 'vod_streams.json')
    m3u_path = os.path.join(ADDON_DATA, 'movies_complete.m3u')

    if not os.path.exists(json_path):
        DIALOG.ok(ADDON_NAME, 'Primero entra en Películas')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        movies_list = []
        if isinstance(data, list):
            movies_list = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    movies_list = v
                    break

        dns = GET_SET.getSetting('DNS')
        user = GET_SET.getSetting('Username')
        pw = GET_SET.getSetting('Password')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write('# Lista de películas con metadatos completos\n\n')
            
            for movie in movies_list:
                if not isinstance(movie, dict):
                    continue
                name = movie.get('name', '')
                stream_id = movie.get('stream_id', '')
                logo = movie.get('stream_icon', '')
                group = movie.get('category_name', '')

                # Obtener sinopsis/plot
                plot = movie.get('plot', '')
                if not plot and 'description' in movie:
                    plot = movie.get('description', '')
                if not plot and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        plot = info.get('plot', '') or info.get('description', '')
                
                # Obtener año
                year = movie.get('year', '')
                if not year:
                    year_match = re.search(r'\((\d{4})\)', name)
                    if year_match:
                        year = year_match.group(1)
                    elif 'releaseDate' in movie:
                        release = movie.get('releaseDate', '')
                        if release and len(release) >= 4:
                            year = release[:4]
                
                # Obtener rating
                rating = movie.get('rating', '')
                if not rating and 'rating_5based' in movie:
                    rating = movie.get('rating_5based', '')
                
                # Obtener duración
                duration = movie.get('duration', '')
                if not duration and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        duration = info.get('duration', '')
                
                # Obtener director
                director = movie.get('director', '')
                if not director and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        director = info.get('director', '')
                
                # Obtener cast
                cast = movie.get('cast', '')
                if not cast and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        cast = info.get('cast', '')
                
                # Obtener género
                genre = movie.get('genre', '')
                if not genre and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        genre = info.get('genre', '')

                ext = movie.get('container_extension', 'mp4')
                url = f"{dns}/movie/{user}/{pw}/{stream_id}.{ext}"

                # Escribir línea EXTINF
                if group and group != 'Sin categoría':
                    m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n')
                    m3u.write(f'#EXTGENRE:{group}\n')
                else:
                    m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}",{name}\n')
                
                # Añadir metadatos
                if plot:
                    plot_clean = plot.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTDESC:{plot_clean}\n')
                if year:
                    m3u.write(f'#EXTYEAR:{year}\n')
                if rating:
                    m3u.write(f'#EXTRATING:{rating}\n')
                if duration:
                    m3u.write(f'#EXTDURATION:{duration}\n')
                if director:
                    director_clean = director.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTDIRECTOR:{director_clean}\n')
                if cast:
                    cast_clean = cast.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTCAST:{cast_clean}\n')
                if genre and genre != group:
                    m3u.write(f'#EXTGENRE2:{genre}\n')
                m3u.write(f'{url}\n\n')
        DIALOG.notification(ADDON_NAME, 'Lista generada', ICON, 3000)
    except Exception as e:
        log(f'Error: {e}')
        DIALOG.ok(ADDON_NAME, f'Error: {str(e)}')

def generate_movies_all_meta():
    """Genera M3U con todos los metadatos disponibles."""
    json_path = os.path.join(ADDON_DATA, 'vod_streams.json')
    m3u_path = os.path.join(ADDON_DATA, 'movies_all_meta.m3u')

    if not os.path.exists(json_path):
        DIALOG.ok(ADDON_NAME, 'Primero entra en Películas')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        movies_list = []
        if isinstance(data, list):
            movies_list = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    movies_list = v
                    break

        dns = GET_SET.getSetting('DNS')
        user = GET_SET.getSetting('Username')
        pw = GET_SET.getSetting('Password')

        # Crear diálogo de progreso
        dp = xbmcgui.DialogProgress()
        dp.create(ADDON_NAME, "Generando lista con todos los metadatos...")
        total = len(movies_list)
        
        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            m3u.write('# Lista de películas con TODOS los metadatos disponibles\n\n')
            
            for idx, movie in enumerate(movies_list):
                if not isinstance(movie, dict):
                    continue
                
                # Actualizar progreso
                if idx % 10 == 0:
                    progress = int((idx + 1) * 100 / total)
                    dp.update(progress, f"Procesando: {idx+1}/{total}")
                    if dp.iscanceled():
                        dp.close()
                        return
                
                name = movie.get('name', '')
                stream_id = movie.get('stream_id', '')
                logo = movie.get('stream_icon', '')
                group = movie.get('category_name', '')

                # Obtener sinopsis/plot desde múltiples fuentes
                plot = movie.get('plot', '')
                if not plot and 'description' in movie:
                    plot = movie.get('description', '')
                if not plot and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        plot = info.get('plot', '') or info.get('description', '') or info.get('synopsis', '')
                
                # Obtener año
                year = movie.get('year', '')
                if not year:
                    year_match = re.search(r'\((\d{4})\)', name)
                    if year_match:
                        year = year_match.group(1)
                    elif 'releaseDate' in movie:
                        release = movie.get('releaseDate', '')
                        if release and len(release) >= 4:
                            year = release[:4]
                
                # Obtener ratings
                rating = movie.get('rating', '')
                rating_5based = movie.get('rating_5based', '')
                if not rating and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        rating = info.get('rating', '')
                
                # Obtener duración
                duration = movie.get('duration', '')
                if not duration and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        duration = info.get('duration', '')
                
                # Obtener director
                director = movie.get('director', '')
                if not director and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        director = info.get('director', '')
                
                # Obtener cast
                cast = movie.get('cast', '')
                if not cast and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        cast = info.get('cast', '')
                
                # Obtener género
                genre = movie.get('genre', '')
                if not genre and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        genre = info.get('genre', '')
                
                # Obtener backdrop
                backdrop = movie.get('backdrop_path', [''])[0] if isinstance(movie.get('backdrop_path'), list) else movie.get('backdrop_path', '')
                if not backdrop and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        backdrop = info.get('backdrop_path', [''])[0] if isinstance(info.get('backdrop_path'), list) else info.get('backdrop_path', '')
                
                # Obtener release date
                release_date = movie.get('releaseDate', '')
                if not release_date and 'info' in movie:
                    info = movie.get('info', {})
                    if isinstance(info, dict):
                        release_date = info.get('releaseDate', '')

                ext = movie.get('container_extension', 'mp4')
                url = f"{dns}/movie/{user}/{pw}/{stream_id}.{ext}"

                # Escribir línea EXTINF
                if group and group != 'Sin categoría':
                    m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n')
                    m3u.write(f'#EXTGENRE:{group}\n')
                else:
                    m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}",{name}\n')
                
                # Añadir todos los metadatos disponibles
                if genre and genre != group and genre != 'Sin categoría':
                    m3u.write(f'#EXTGENRE2:{genre}\n')
                if plot:
                    plot_clean = plot.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTDESC:{plot_clean}\n')
                if year:
                    m3u.write(f'#EXTYEAR:{year}\n')
                if rating:
                    m3u.write(f'#EXTRATING:{rating}\n')
                if rating_5based:
                    m3u.write(f'#EXTRATING5:{rating_5based}\n')
                if duration:
                    m3u.write(f'#EXTDURATION:{duration}\n')
                if director:
                    director_clean = director.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTDIRECTOR:{director_clean}\n')
                if cast:
                    cast_clean = cast.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTCAST:{cast_clean}\n')
                if release_date:
                    m3u.write(f'#EXTDATE:{release_date}\n')
                if backdrop:
                    m3u.write(f'#EXTBACKDROP:{backdrop}\n')
                m3u.write(f'{url}\n\n')
        
        dp.close()
        DIALOG.notification(ADDON_NAME, 'Lista generada', ICON, 3000)
    except Exception as e:
        log(f'Error: {e}')
        try:
            dp.close()
        except:
            pass
        DIALOG.ok(ADDON_NAME, f'Error: {str(e)}')

def generate_movies_all_meta():
    """Genera M3U con todos los metadatos disponibles."""
    json_path = os.path.join(ADDON_DATA, 'vod_streams.json')
    m3u_path = os.path.join(ADDON_DATA, 'movies_all_meta.m3u')

    if not os.path.exists(json_path):
        DIALOG.ok(ADDON_NAME, 'Primero entra en Películas')
        return

    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        movies_list = []
        if isinstance(data, list):
            movies_list = data
        elif isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    movies_list = v
                    break

        dns = GET_SET.getSetting('DNS')
        user = GET_SET.getSetting('Username')
        pw = GET_SET.getSetting('Password')

        with open(m3u_path, 'w', encoding='utf-8') as m3u:
            m3u.write('#EXTM3U\n')
            for movie in movies_list:
                if not isinstance(movie, dict):
                    continue
                name = movie.get('name', '')
                stream_id = movie.get('stream_id', '')
                logo = movie.get('stream_icon', '')
                group = movie.get('category_name', '')

                plot = movie.get('plot', '')
                year = movie.get('year', '')
                rating = movie.get('rating', '')
                rating_5based = movie.get('rating_5based', '')
                duration = movie.get('duration', '')
                director = movie.get('director', '')
                cast = movie.get('cast', '')
                genre = movie.get('genre', '')
                release_date = movie.get('releaseDate', '')
                backdrop = movie.get('backdrop_path', [''])[0] if isinstance(movie.get('backdrop_path'), list) else movie.get('backdrop_path', '')

                if not plot and 'description' in movie:
                    plot = movie.get('description', '')
                if not year and release_date:
                    year = release_date[:4]
                if not year:
                    year_match = re.search(r'\((\d{4})\)', name)
                    if year_match:
                        year = year_match.group(1)

                ext = movie.get('container_extension', 'mp4')
                url = f"{dns}/movie/{user}/{pw}/{stream_id}.{ext}"

                m3u.write(f'#EXTINF:-1 tvg-id="{stream_id}" tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}\n')
                if genre and genre != group:
                    m3u.write(f'#EXTGENRE2:{genre}\n')
                if plot:
                    plot_clean = plot.replace('\n', ' ').replace('\r', '')
                    m3u.write(f'#EXTDESC:{plot_clean}\n')
                if year:
                    m3u.write(f'#EXTYEAR:{year}\n')
                if rating:
                    m3u.write(f'#EXTRATING:{rating}\n')
                if rating_5based:
                    m3u.write(f'#EXTRATING5:{rating_5based}\n')
                if duration:
                    m3u.write(f'#EXTDURATION:{duration}\n')
                if director:
                    m3u.write(f'#EXTDIRECTOR:{director}\n')
                if cast:
                    m3u.write(f'#EXTCAST:{cast}\n')
                if release_date:
                    m3u.write(f'#EXTDATE:{release_date}\n')
                if backdrop:
                    m3u.write(f'#EXTBACKDROP:{backdrop}\n')
                m3u.write(f'{url}\n\n')
        DIALOG.notification(ADDON_NAME, 'Lista generada', ICON, 3000)
    except Exception as e:
        log(f'Error: {e}')
        DIALOG.ok(ADDON_NAME, f'Error: {str(e)}')

##########################=INTERACCIÓN CON EL USUARIO========================
def keypopup(heading):
    kb = xbmc.Keyboard('', heading, True)
    kb.setHeading(heading)
    kb.setHiddenInput(False)
    kb.doModal()
    if kb.isConfirmed():
        return kb.getText()
    return False

def refresh_epg():
    xbmc.log('IPTVXC: Refrescando EPG/Guía', 1)
    xbmcgui.Dialog().ok('Refrescar EPG/Guía', 'Refrescando datos...')
    xbmc.executebuiltin('RunPlugin(plugin://pvr.iptvsimple/?action=resetepg)')
    xbmc.executebuiltin('Container.Refresh')
    xbmcgui.Dialog().ok('Refrescar EPG/Guía', 'Solicitud enviada. Si no ves cambios, reinicia Kodi.')